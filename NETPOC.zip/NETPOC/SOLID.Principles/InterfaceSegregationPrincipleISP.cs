﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace SOLID.Principles
{
    /// <summary>
    /// Before: Interfaces may be too large, forcing classes to implement methods they don't need.
    /// After: A class should not be forced to implement interfaces it does not use.Instead, multiple smaller, 
    /// specific interfaces should be preferred over a large, general one.
    /// </summary>
    internal class InterfaceSegregationPrincipleISP
    {
    }


    //After ISP
    public interface IWorker
    {
        void Work();
    }

    public interface IEater
    {
        void Eat();
    }

    public class Manager : IWorker, IEater
    {
        public void Work()
        {
            // Manage tasks
        }

        public void Eat()
        {
            // Eat lunch
        }
    }


    //Before ISP:
    //public interface IWorker
    //{
    //    void Work();
    //    void Eat();
    //}

    //public class Manager : IWorker
    //{
    //    public void Work()
    //    {
    //        // Manage tasks
    //    }

    //    public void Eat()
    //    {
    //        // Eat lunch
    //    }
    //}
}
