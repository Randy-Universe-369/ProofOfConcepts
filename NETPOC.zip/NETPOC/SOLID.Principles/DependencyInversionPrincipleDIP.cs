﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace SOLID.Principles
{
    /// <summary>
    /// Before: High-level modules depend on low-level modules, making the system rigid and difficult to change.
    /// After: Abstractions should not depend on details; rather, details should depend on abstractions.
    /// High-level modules and low-level modules should both depend on abstractions.
    /// </summary>
    internal class DependencyInversionPrincipleDIP
    {
    }


    //After DIP
    public interface ISwitchable
    {
        void TurnOn();
        void TurnOff();
        bool IsOn();
    }

    public class LightBulb : ISwitchable
    {
        public void TurnOn()
        {
            // Turn on the light bulb
        }

        public void TurnOff()
        {
            // Turn off the light bulb
        }

        public bool IsOn()
        {
            return false;
        }
    }

    public class Switch
    {
        private ISwitchable device;

        public Switch(ISwitchable device)
        {
            this.device = device;
        }

        public void Toggle()
        {
            if (device.IsOn())
            {
                device.TurnOff();
            }
            else
            {
                device.TurnOn();
            }
        }
    }


    //Before DIP
    //public class LightBulb
    //{
    //    public void TurnOn()
    //    {
    //        // Turn on the light bulb
    //    }

    //    public void TurnOff()
    //    {
    //        // Turn off the light bulb
    //    }

    //    public bool IsOn()
    //    {
    //        return true;
    //    }
    //}

    //public class Switch
    //{
    //    private LightBulb bulb;

    //    public Switch()
    //    {
    //        this.bulb = new LightBulb();
    //    }

    //    public void Toggle()
    //    {
    //        if (bulb.IsOn())
    //        {
    //            bulb.TurnOff();
    //        }
    //        else
    //        {
    //            bulb.TurnOn();
    //        }
    //    }
    //}

}
