﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID.Principles
{
    /// <summary>
    /// Before: Subtypes might not be true substitutes for their base types, leading to unexpected behavior.
    /// After: Subtypes should be substitutable for their base types without altering the correctness of the program.
    /// </summary>
    internal class LiskovSubstitutionPrincipleLSP
    {
    }

    //After LSP

    public interface IFlyable
    {
        void Fly();
    }

    public class Bird : IFlyable
    {
        public virtual void Fly()
        {
            Console.WriteLine("Flying...");
        }
    }

    public class Penguin : IFlyable
    {
        public void Fly()
        {
            Console.WriteLine("I can't fly!");
        }
    }




    //Before LSP
    //public class Bird
    //{
    //    public virtual void Fly()
    //    {
    //        Console.WriteLine("Flying...");
    //    }
    //}

    //public class Penguin : Bird
    //{
    //    // This violates LSP
    //    public override void Fly()
    //    {
    //        Console.WriteLine("I can't fly!");
    //    }
    //}

}
