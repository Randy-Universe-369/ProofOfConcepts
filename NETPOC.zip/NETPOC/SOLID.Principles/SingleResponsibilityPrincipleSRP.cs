﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLID.Principles
{
    /// <summary>
    /// Before: A class or module may have multiple responsibilities, making it difficult to understand, maintain, and change.
    /// After: Each class or module should have only one reason to change, meaning it should have only one responsibility.
    /// Note: You need to remember that, as we have the Inheritance concept, that does not mean we can randomly create the relationship between classes. 
    /// We will not get any error or exception, but the behavior that we expect might not be. So, always make sure that the relationship and functionality 
    /// we provide make sense. If it makes sense, then go for the inheritance relationship; if not, then don’t go for the inheritance relationship.
    /// </summary>
    internal class SingleResponsibilityPrincipleSRP
    {
    }

    //After SRP:
    //Best Practice
    public class Report
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }

    public class ReportGenerator
    {
        public void GenerateReport(Report report)
        {
            // Generate the report
        }
    }

    public class ReportSaver
    {
        public void SaveToFile(Report report)
        {
            // Save the report to a file
        }
    }


    //Before SRP:
    //Bad Practice
    //public class Report
    //{
    //    public string Title { get; set; }
    //    public string Content { get; set; }

    //    public void GenerateReport()
    //    {
    //        // Generate the report
    //    }

    //    public void SaveToFile()
    //    {
    //        // Save the report to a file
    //    }
    //}

}
