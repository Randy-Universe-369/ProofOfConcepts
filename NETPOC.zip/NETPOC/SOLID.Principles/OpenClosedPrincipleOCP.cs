﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace SOLID.Principles
{
    /// <summary>
    /// Before: Code might need to be modified directly when adding new functionality, potentially breaking existing code.
    /// After: Software entities(classes, modules, functions, etc.) should be open for extension but closed for modification.
    /// New functionality should be added by extending existing code, not by changing it.
    /// </summary>
    internal class OpenClosedPrincipleOCP
    {
    }

    //Good Practice, After OCP:
    public abstract class Shape
    {
        public abstract double CalculateArea();
    }

    public class Rectangle : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public override double CalculateArea()
        {
            return Width * Height;
        }
    }

    public class Circle : Shape
    {
        public double Radius { get; set; }

        public override double CalculateArea()
        {
            return Math.PI * Radius * Radius;
        }
    }



    //Bad Practice, Before OCP:
    //public class Rectangle
    //{
    //    public double Width { get; set; }
    //    public double Height { get; set; }
    //}

    //public class AreaCalculator
    //{
    //    public double CalculateArea(Rectangle rectangle)
    //    {
    //        return rectangle.Width * rectangle.Height;
    //    }
    //}

}
