﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.ReadOnly_Const
{
    public class ReadonlyAndConst
    {
        #region read only and const and Override ToString method

        //read only and const
        public class User
        {
            readonly int variable = 10;
            const int constValue = 5;


            public User(int val)
            {
                variable = val;
                variable += val;
                variable += val;
                Console.WriteLine(variable);

            }
            public void GetMarks()
            {

                //IMarks marks = new Science();
                //marks.GetMarks();
            }

        }

        //Override ToString method
        public class User2
        {
            public override string ToString()
            {
                return base.ToString();
            }
        }
        #endregion

    }
}
