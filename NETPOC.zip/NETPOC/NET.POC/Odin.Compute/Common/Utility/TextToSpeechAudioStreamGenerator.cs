﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Odin.Compute.Common.Utility
{
    public class TextToSpeechAudioStreamGenerator : IAudioStreamGenerator
    {
        SpeechSynthesizer _speechSynthesizer { get; set; }

        /// <summary>
        /// Gets or sets the text to speak.
        /// </summary>
        /// <value>
        /// The text to speak.
        /// </value>
        public string TextToSpeak { get; set; }

        /// <summary>
        /// Gets or sets the milliseconds to trim from start after the text to speech is generated
        /// </summary>
        /// <value>
        /// The milliseconds to trim from start.
        /// </value>
        public int MillisecondsToTrimFromStart
        {
            get
            {
                return _millisecondsToTrimFromStart;
            }
            set
            {
                _millisecondsToTrimFromStart = value;
            }
        }
        private int _millisecondsToTrimFromStart = 100;

        /// <summary>
        /// Gets or sets the milliseconds to trim from end after the text to speech is generated
        /// </summary>
        /// <value>
        /// The milliseconds to trim from end.
        /// </value>
        public int MillisecondsToTrimFromEnd
        {
            get
            {
                return _millisecondsToTrimFromEnd;
            }
            set
            {
                _millisecondsToTrimFromEnd = value;
            }
        }
        private int _millisecondsToTrimFromEnd = 760;

        public TextToSpeechAudioStreamGenerator()
        {
            _speechSynthesizer = new SpeechSynthesizer();
            //Get the speech rate from the system configuration if it exists, otherwise default to 0
            int speechSynthesizerRate = 0;

            //Get the configuration
            string speechSynthesizerRateSystemConfiguration = "0";


            //Make sure it isn't null
            if (speechSynthesizerRateSystemConfiguration != null)
            {
                //Try to parse it otherwise set it to zero
                if (!Int32.TryParse(speechSynthesizerRateSystemConfiguration, out speechSynthesizerRate))
                {
                    speechSynthesizerRate = 0;
                }

            }

            //Set the speech synthesizer rate
            _speechSynthesizer.Rate = speechSynthesizerRate;

            //Get all of the installed voices
            var installedVoices = _speechSynthesizer.GetInstalledVoices();
            //Throw an exception if the installed voices don't exist
            if (installedVoices == null || installedVoices.Count == 0)
            {
                throw new Exception("There are no installed voices for text to speech generation.");
            }

            //Set the default voice to the first installed voice name
            string textToSpeechVoiceName = installedVoices[0].VoiceInfo.Name;

            //Get the configured voice name from the database
            string textToSpeechVoiceNameSystemCongfigurationType = "Microsoft Zira Desktop";

            //If it's not null, then make sure it's a voice that is in the list of installed voices and use it
            if (textToSpeechVoiceNameSystemCongfigurationType != null)
            {
                //Make sure this voice exists in the installed voices
                if (installedVoices.Count(x => x.VoiceInfo.Name == textToSpeechVoiceNameSystemCongfigurationType) > 0)
                {
                    //It does, so use it
                    Console.WriteLine($"textToSpeechVoiceNameSystemCongfigurationType: {textToSpeechVoiceNameSystemCongfigurationType}");
                    textToSpeechVoiceName = textToSpeechVoiceNameSystemCongfigurationType;
                }
            }
            try
            {
                Console.WriteLine($"TextToSpeechAudioStreamGenerator: TextToSpeechVoiceName: {textToSpeechVoiceName}");

                //Select the voice
                Console.WriteLine($"Start synthesizer SelectVoice: {textToSpeechVoiceNameSystemCongfigurationType}");
                _speechSynthesizer.SelectVoice(textToSpeechVoiceName);
                Console.WriteLine($"Finish synthesizer SelectVoice:");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error occurred when trying to select text-to-speech voice: {textToSpeechVoiceName}.  Error: {ex.ToString()}");
                throw;
            }
        }

        public MemoryStream GenerateAudioStream()
        {
            MemoryStream trimmedStream = new MemoryStream();
            try
            {
                Console.WriteLine($"TextToSpeechAudioStreamGenerator: Generate Audio Stream for Text");

                //Instantiate a new output stream
                MemoryStream outputStream = new MemoryStream();

                //Create a WAV stream with the TTS
                Console.WriteLine($"Start synthesizer.SetOutputToWaveStream");
                _speechSynthesizer.SetOutputToWaveStream(outputStream);
                Console.WriteLine($"Finish synthesizer.SetOutputToWaveStream:");

                //Play the message into the wav file
                _speechSynthesizer.Speak(TextToSpeak);
                Console.WriteLine($"synthesizer.Speak:");

                //Reset the stream position to zero
                outputStream.Position = 0;

                //Trim the generated audio file using the audio file helper
                AudioFileHelper audioFileHelper = new AudioFileHelper();
                trimmedStream = audioFileHelper.Trim(outputStream, this.MillisecondsToTrimFromStart, this.MillisecondsToTrimFromEnd);

                //Reset the stream position to zero
                trimmedStream.Position = 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[TextToSpeechAudioStreamGenerator] - Error occurred on GenerateAudioStream method.  Error: {ex.ToString()}");
            }
            //Return the stream
            return trimmedStream;
        }
    }
}
