﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Odin.Compute.Common.Utility
{
    public interface IAudioStreamGenerator
    {
        MemoryStream GenerateAudioStream();
    }
}
