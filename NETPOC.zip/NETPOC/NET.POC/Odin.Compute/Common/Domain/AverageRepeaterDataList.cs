﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Odin.Compute.Common.Domain
{
    public class AverageRepeaterDataList : List<AverageRepeaterDataItem>
    {
        public void AddAverage(uint firstHopDeviceUniqueId, float signalLevel, float signalMargin, float hopCount)
        {
            AverageRepeaterDataItem objectToAverage = this.Where(x => x.FirstHopDeviceUniqueId == firstHopDeviceUniqueId).FirstOrDefault();
            if (objectToAverage == null)
            {
                this.Add(new AverageRepeaterDataItem()
                {
                    FirstHopDeviceUniqueId = firstHopDeviceUniqueId,
                    AverageSignalLevel = signalLevel,
                    AverageSignalMargin = signalMargin,
                    LowestHopCount = hopCount,
                    RepeaterMessagesInClusterCount = 1
                });
            }
            else
            {
                //To adjust average: new_average = old_average + ((value - old_average) / new_size)
                objectToAverage.RepeaterMessagesInClusterCount += 1;
                objectToAverage.AverageSignalLevel = objectToAverage.AverageSignalLevel + ((signalLevel - objectToAverage.AverageSignalLevel) / objectToAverage.RepeaterMessagesInClusterCount);
                objectToAverage.AverageSignalMargin = objectToAverage.AverageSignalMargin + ((signalLevel - objectToAverage.AverageSignalMargin) / objectToAverage.RepeaterMessagesInClusterCount);
                objectToAverage.LowestHopCount = objectToAverage.LowestHopCount > hopCount ? hopCount : objectToAverage.LowestHopCount;
            }
        }

        public void Combine(AverageRepeaterDataList averageRepeaterDataListToCombine)
        {
            foreach (AverageRepeaterDataItem averageRepeaterDataToAdd in averageRepeaterDataListToCombine)
            {
                AddAverage(averageRepeaterDataToAdd.FirstHopDeviceUniqueId, averageRepeaterDataToAdd.AverageSignalLevel, averageRepeaterDataToAdd.AverageSignalMargin, averageRepeaterDataToAdd.LowestHopCount);
            }
        }

    }
}
