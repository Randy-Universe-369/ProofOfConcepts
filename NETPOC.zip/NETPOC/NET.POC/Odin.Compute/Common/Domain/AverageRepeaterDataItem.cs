﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Odin.Compute.Common.Domain
{
    public class AverageRepeaterDataItem
    {
        public uint FirstHopDeviceUniqueId { get; set; }
        public float AverageSignalLevel { get; set; }
        public float AverageSignalMargin { get; set; }
        public float LowestHopCount { get; set; }
        public int RepeaterMessagesInClusterCount { get; set; }
    }
}
