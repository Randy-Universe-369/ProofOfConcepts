﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Enumerations
{
    public enum EchoStreamFirstHopDevice
    {
        RFGateway = 0x00,
        Repeater = 0x01
    }

    [Flags]
    public enum EchoStreamApplicationStatusFlags
    {
        Unset = 0x00,                   //Decimal: 0
        PrimaryAlarm = 0x01,            //Decimal: 1
        SecondAlarm = 0x02,             //Decimal: 2
        ThirdAlarm = 0x04,              //Decimal: 4
        FourthAlarm = 0x08,             //Decimal: 8
        ClearByButton = 0x10,           //Decimal: 16 
        ClearByMagnet = 0x20,           //Decimal: 32
        CleanMeMessage = 0x40,          //Decimal: 64
        EndOfLineTamper = 0x80          //Decimal: 128
    }

    [Flags]
    public enum EchoStreamPrimaryStatusFlags
    {
        Unset = 0x00,                   //Decimal: 0
        SequenceBit0 = 0x01,            //Decimal: 1
        SequenceBit1 = 0x02,            //Decimal: 2
        PrimaryBatteryMissing = 0x04,   //Decimal: 4
        Reset = 0x08,                   //Decimal: 8
        NoChange = 0x10,                //Decimal: 16 - Supervisory
        Tamper = 0x20,                  //Decimal: 32
        LowBatteryPrimary = 0x40,       //Decimal: 64
        LowBatteryInternal = 0x80      //Decimal: 128
    }


    public enum TransmissionInterval
    {
        TenSecond = 0,
        ThirtySecond = 1,
        OneMinute = 2,
        TwoMinutes = 3,
        FiveMinutes = 4,
        TenMinutes = 5,
        FifteenMinutes = 6,
        ThirtyMinutes = 7,
    }


    public enum MeasurementInterval
    {
        OnlyOnTransmission = 0,
        HalfSecond = 1,
        OneSecond = 2,
        FiveSeconds = 3,
        ThirtySeconds = 4,
        OneMinutes = 5,
        TenMinutes = 6,
        FifteenMinutes = 7,
    }

    public enum ExternalSensorUnits
    {
        Resistance = 0,
        Temperature = 1,
    }

    public enum TemperatureUnits
    {
        Celsius = 0,
        Fahrenheit = 1,
    }

    public enum DeltaTValue
    {
        FeatureDisabled = 0,
        Half = 1,
        One = 2,
        Five = 3,
        Ten = 4
    }

    public enum InovonicsMarketId
    {
        SecurityEndDevices = 0xB2,
        EnvironmentalEndDevices = 0xC0,
        SubmeteringProducts = 0xA0,
        HighPowerRepeaters = 0x01,
        NetworkCoordinators = 0x00,
        StanleyCallboxDevice1 = 0x11,
        StanleyCallboxDevice2 = 0x12,
        StanleyCallboxDevice3 = 0X02,
        StanleyCallboxDevice4 = 0X03,
        StanleyCallboxDevice5 = 0X04,
        StanleyCallboxDevice6 = 0X05,
        StanleyCallboxDevice7 = 0x06,
        StanleyCallboxDevice8 = 0x07,
        StanleyCallboxDevice9 = 0x08,
        StanleyCallboxDevice10 = 0x09,
        StanleyCallboxDevice11 = 0x0A,
        StanleyCallboxDevice12 = 0x0B,
        StanleyCallboxDevice13 = 0x0C,
        StanleyCallboxDevice14 = 0x0D,
        StanleyCallboxDevice15 = 0x0E,
        StanleyCallboxDevice16 = 0x0F,
        StanleyCallboxDevice17 = 0x10,
        StanleyCallboxDevice18 = 0x13,
        StanleyCallboxDevice19 = 0x14,
        StanleyCallboxDevice20 = 0x15,
        StanleyCallboxDevice21 = 0x16,
        StanleyCallboxDevice22 = 0x17,
        StanleyCallboxDevice23 = 0x18,
        StanleyCallboxDevice24 = 0x19,
        StanleyCallboxDevice25 = 0x1A,
        StanleyCallboxDevice26 = 0x1B,
        StanleyCallboxDevice27 = 0x1C,
        StanleyCallboxDevice28 = 0x1D,
        StanleyCallboxDevice29 = 0x1E,
        StanleyCallboxDevice30 = 0x1F,
        StanleyCallboxDevice31 = 0x20,
        StanleyCallboxDevice32 = 0x21,
        StanleyCallboxDevice33 = 0x22,
        StanleyCallboxDevice34 = 0x23,
        StanleyCallboxDevice35 = 0x24,
        StanleyCallboxDevice36 = 0x25,
        StanleyCallboxDevice37 = 0x26,
        StanleyCallboxDevice38 = 0x27,
        StanleyCallboxDevice39 = 0x28,
        StanleyCallboxDevice40 = 0x29,
        StanleyCallboxDevice41 = 0x2A,
        StanleyCallboxDevice42 = 0x2B,
        StanleyCallboxDevice43 = 0x2C,
        StanleyCallboxDevice44 = 0x2D,
        StanleyCallboxDevice45 = 0x2E,
        StanleyCallboxDevice46 = 0x2F,
        StanleyCallboxDevice47 = 0x30,
        StanleyCallboxDevice48 = 0x31,
        StanleyCallboxDevice49 = 0x32,
        StanleyCallboxDevice50 = 0x33,
        StanleyCallboxDevice51 = 0x34,
        StanleyCallboxDevice52 = 0x35,
        StanleyCallboxDevice53 = 0x36,
        StanleyCallboxDevice54 = 0x37,
        StanleyCallboxDevice55 = 0x38,
        StanleyCallboxDevice56 = 0x39,
        StanleyCallboxDevice57 = 0x3A,
        StanleyCallboxDevice58 = 0x3B,
        StanleyCallboxDevice59 = 0x3C,
        StanleyCallboxDevice60 = 0x3D,
        StanleyCallboxDevice61 = 0x3E,
        StanleyCallboxDevice62 = 0x3F,
        StanleyCallboxDevice63 = 0x40,
        StanleyCallboxDevice64 = 0x41,
        StanleyCallboxDevice65 = 0x42,
        StanleyCallboxDevice66 = 0x43,
        StanleyCallboxDevice67 = 0x44,
        StanleyCallboxDevice68 = 0x45,
        StanleyCallboxDevice69 = 0x46,
        StanleyCallboxDevice70 = 0x47,
        StanleyCallboxDevice71 = 0x48,
        StanleyCallboxDevice72 = 0x49,
        StanleyCallboxDevice73 = 0x4A,
        StanleyCallboxDevice74 = 0x4B,
        StanleyCallboxDevice75 = 0x4C,
        StanleyCallboxDevice76 = 0x4D,
        StanleyCallboxDevice77 = 0x4E,
        StanleyCallboxDevice78 = 0x4F,
        StanleyCallboxDevice79 = 0x50,
        StanleyCallboxDevice80 = 0x51,
        StanleyCallboxDevice81 = 0x52,
        StanleyCallboxDevice82 = 0x53,
        StanleyCallboxDevice83 = 0x54,
        StanleyCallboxDevice84 = 0x55,
        StanleyCallboxDevice85 = 0x56,
        StanleyCallboxDevice86 = 0x57,
        StanleyCallboxDevice87 = 0x58,
        StanleyCallboxDevice88 = 0x59,
        StanleyCallboxDevice89 = 0x5A,
        StanleyCallboxDevice90 = 0x5B,
        StanleyCallboxDevice91 = 0x5C,
        StanleyCallboxDevice92 = 0x5D,
        StanleyCallboxDevice93 = 0x5E,
        StanleyCallboxDevice94 = 0x5F,
        StanleyCallboxDevice95 = 0x60,
        StanleyCallboxDevice96 = 0x61,
        StanleyCallboxDevice97 = 0x62,
        StanleyCallboxDevice98 = 0x63,
        StanleyCallboxDevice99 = 0x64,
        StanleyCallboxDevice100 = 0x65,
        StanleyCallboxDevice101 = 0x66,
        StanleyCallboxDevice102 = 0x67,
        StanleyCallboxDevice103 = 0x68,
        StanleyCallboxDevice104 = 0x69,
        StanleyCallboxDevice105 = 0x6A,
        StanleyCallboxDevice106 = 0x6B,
        StanleyCallboxDevice107 = 0x6C,
        StanleyCallboxDevice108 = 0x6D,
        StanleyCallboxDevice109 = 0x6E,
        StanleyCallboxDevice110 = 0x6F,
        StanleyCallboxDevice111 = 0x70,
        StanleyCallboxDevice112 = 0x71,
        StanleyCallboxDevice113 = 0x72,
        StanleyCallboxDevice114 = 0x73,
        StanleyCallboxDevice115 = 0x74,
        StanleyCallboxDevice116 = 0x75,
        StanleyCallboxDevice117 = 0x76,
        StanleyCallboxDevice118 = 0x77,
        StanleyCallboxDevice119 = 0x78,
        StanleyCallboxDevice120 = 0x79,
        StanleyCallboxDevice121 = 0x7A,
        StanleyCallboxDevice122 = 0x7B,
        StanleyCallboxDevice123 = 0x7C,
        StanleyCallboxDevice124 = 0x7D,
        StanleyCallboxDevice125 = 0x7E,
        StanleyCallboxDevice126 = 0x7F,
        StanleyCallboxDevice127 = 0x80,
        StanleyCallboxDevice128 = 0x81,
        StanleyCallboxDevice129 = 0x82,
        StanleyCallboxDevice130 = 0x83,
        StanleyCallboxDevice131 = 0x84,
        StanleyCallboxDevice132 = 0x85,
        StanleyCallboxDevice133 = 0x86,
        StanleyCallboxDevice134 = 0x87,
        StanleyCallboxDevice135 = 0x88,
        StanleyCallboxDevice136 = 0x89,
        StanleyCallboxDevice137 = 0x8A,
        StanleyCallboxDevice138 = 0x8B,
        StanleyCallboxDevice139 = 0x8C,
        StanleyCallboxDevice140 = 0x8D,
        StanleyCallboxDevice141 = 0x8E,
        StanleyCallboxDevice142 = 0x8F,
        StanleyCallboxDevice143 = 0x90,
        StanleyCallboxDevice144 = 0x91,
        StanleyCallboxDevice145 = 0x92,
        StanleyCallboxDevice146 = 0x93,
        StanleyCallboxDevice147 = 0x94,
        StanleyCallboxDevice148 = 0x95,
        StanleyCallboxDevice149 = 0x96,
        StanleyCallboxDevice150 = 0x97,
        StanleyCallboxDevice151 = 0x98,
        StanleyCallboxDevice152 = 0x99,
        StanleyCallboxDevice153 = 0x9A,
        StanleyCallboxDevice154 = 0x9B,
        StanleyCallboxDevice155 = 0x9C,
        StanleyCallboxDevice156 = 0x9D,
        StanleyCallboxDevice157 = 0x9E,
        StanleyCallboxDevice158 = 0x9F,
        StanleyCallboxDevice159 = 0xA1,
        StanleyCallboxDevice160 = 0xA2,
        StanleyCallboxDevice161 = 0xA3,
        StanleyCallboxDevice162 = 0xA4,
        StanleyCallboxDevice163 = 0xA5,
        StanleyCallboxDevice164 = 0xA6,
        StanleyCallboxDevice165 = 0xA7,
        StanleyCallboxDevice166 = 0xA8,
        StanleyCallboxDevice167 = 0xA9,
        StanleyCallboxDevice168 = 0xAA,
        StanleyCallboxDevice169 = 0xAB,
        StanleyCallboxDevice170 = 0xAC,
        StanleyCallboxDevice171 = 0xAD,
        StanleyCallboxDevice172 = 0xAE,
        StanleyCallboxDevice173 = 0xAF,
        StanleyCallboxDevice174 = 0xB0,
        StanleyCallboxDevice175 = 0xB1,
        StanleyCallboxDevice176 = 0xB3,
        StanleyCallboxDevice177 = 0xB4,
        StanleyCallboxDevice178 = 0xB5,
        StanleyCallboxDevice179 = 0xB6,
        StanleyCallboxDevice180 = 0xB7,
        StanleyCallboxDevice181 = 0xB8,
        StanleyCallboxDevice182 = 0xB9,
        StanleyCallboxDevice183 = 0xBA,
        StanleyCallboxDevice184 = 0xBB,
        StanleyCallboxDevice185 = 0xBC,
        StanleyCallboxDevice186 = 0xBD,
        StanleyCallboxDevice187 = 0xBE,
        StanleyCallboxDevice188 = 0xBF,
        StanleyCallboxDevice189 = 0xC1,
        StanleyCallboxDevice190 = 0xC2,
        StanleyCallboxDevice191 = 0xC3,
        StanleyCallboxDevice192 = 0xC4,
        StanleyCallboxDevice193 = 0xC5,
        StanleyCallboxDevice194 = 0xC6,
        StanleyCallboxDevice195 = 0xC7,
        StanleyCallboxDevice196 = 0xC8,
        StanleyCallboxDevice197 = 0xC9,
        StanleyCallboxDevice198 = 0xCA,
        StanleyCallboxDevice199 = 0xCB,
        StanleyCallboxDevice200 = 0xCC,
        StanleyCallboxDevice201 = 0xCD,
        StanleyCallboxDevice202 = 0xCE,
        StanleyCallboxDevice203 = 0xCF,
        StanleyCallboxDevice204 = 0xD0,
        StanleyCallboxDevice205 = 0xD1,
        StanleyCallboxDevice206 = 0xD2,
        StanleyCallboxDevice207 = 0xD3,
        StanleyCallboxDevice208 = 0xD4,
        StanleyCallboxDevice209 = 0xD5,
        StanleyCallboxDevice210 = 0xD6,
        StanleyCallboxDevice211 = 0xD7,
        StanleyCallboxDevice212 = 0xD8,
        StanleyCallboxDevice213 = 0xD9,
        StanleyCallboxDevice214 = 0xDA,
        StanleyCallboxDevice215 = 0xDB,
        StanleyCallboxDevice216 = 0xDC,
        StanleyCallboxDevice217 = 0xDD,
        StanleyCallboxDevice218 = 0xDE,
        StanleyCallboxDevice219 = 0xDF,
        StanleyCallboxDevice220 = 0xE0,
        StanleyCallboxDevice221 = 0xE1,
        StanleyCallboxDevice222 = 0xE2,
        StanleyCallboxDevice223 = 0xE3,
        StanleyCallboxDevice224 = 0xE4,
        StanleyCallboxDevice225 = 0xE5,
        StanleyCallboxDevice226 = 0xE6,
        StanleyCallboxDevice227 = 0xE7,
        StanleyCallboxDevice228 = 0xE8,
        StanleyCallboxDevice229 = 0xE9,
        StanleyCallboxDevice230 = 0xEA,
        StanleyCallboxDevice231 = 0xEB,
        StanleyCallboxDevice232 = 0xEC,
        StanleyCallboxDevice233 = 0xED,
        StanleyCallboxDevice234 = 0xEE,
        StanleyCallboxDevice235 = 0xEF,
        StanleyCallboxDevice236 = 0xF0,
        StanleyCallboxDevice237 = 0xF1,
        StanleyCallboxDevice238 = 0xF2,
        StanleyCallboxDevice239 = 0xF3,
        StanleyCallboxDevice240 = 0xF4,
        StanleyCallboxDevice241 = 0xF5,
        StanleyCallboxDevice242 = 0xF6,
        StanleyCallboxDevice243 = 0xF7,
        StanleyCallboxDevice244 = 0xF8,
        StanleyCallboxDevice245 = 0xF9,
        StanleyCallboxDevice246 = 0xFA,
        StanleyCallboxDevice247 = 0xFB,
        StanleyCallboxDevice248 = 0xFC,
        StanleyCallboxDevice249 = 0xFD,
        StanleyCallboxDevice250 = 0xFE,
        StanleyCallboxDevice251 = 0xFF

    }
}
