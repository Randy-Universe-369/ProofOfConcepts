﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml;

namespace NET.POC
{
    internal class ConvertJSONStructure
    {

        public void JSONFormatConvert()
        {
            // Load the JSON from the file
            //string jsonText = File.ReadAllText("data.json");
            string configPath = Path.Combine(Environment.CurrentDirectory, "config", "D:\\PC\\.NET Learning Curve\\POC\\NETPOC\\NET.POC\\Configurations\\CLU.json");
            if (File.Exists(configPath))
            {
                string jsonContent = File.ReadAllText(configPath);
                JObject jsonObject = JObject.Parse(jsonContent);

                // Then proceed to work with the JSON content

                // Create a new structure
                var transformedData = new
                {
                    IntentConfigurationData = new
                    {
                        LabeledUtteranceInfos = new
                        {
                            LabeledUtteranceInfo = jsonObject["value"]
                                .Select(j => new
                                {
                                    Id = new Random().Next(1000000000, int.MaxValue), // You can generate the Id as needed
                                    Text = j["text"],
                                    TokenizedText = new { @string = j["text"].ToString().Split(' ') },
                                    IntentLabel = j["intentsResult"]["predictedIntent"],
                                    EntityLabels = "", // Add the entity labels if available
                                    IntentPredictions = new
                                    {
                                        IntentPrediction = new List<object> {
                                    new { Name = j["intentsResult"]["predictedIntent"], Score = 1 } // Single intent based on provided data
                                                                                                    // Add other predictions here
                                        }
                                    },
                                    EntityPredictions = new
                                    {
                                        EntityPrediction = j["entitiesResult"]["predictedEntities"]
                                            .Select(e => new
                                            {
                                                EntityName = e["category"],
                                                StartTokenIndex = e["offset"],
                                                EndTokenIndex = (int)e["offset"] + (int)e["length"],
                                                Phrase = j["text"].ToString().Substring(e["offset"].ToObject<int>(), e["length"].ToObject<int>())
                                            })
                                    }
                                })
                        }
                    }
                };

                string transformedJson = JsonConvert.SerializeObject(transformedData, Newtonsoft.Json.Formatting.Indented);
                Console.WriteLine(transformedJson);
            }


        }

    }
}
