﻿using System.Text.RegularExpressions;
using System.Text;
using RJCP.IO.Ports;
using Microsoft.Extensions.Logging;
using NET.POC.CLU;
using NET.POC.RegexOperation;
using NET.POC.Transmitter;
using NET.POC.ProductionIssue;
using NET.POC.AzureBlob;
using Newtonsoft.Json.Linq;
using System.Text.Json.Nodes;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;
using System;
using static NET.POC.Program;
using NET.POC.MicroLocation;
using System.Media;
using NET.POC.Odin.Compute.Common.Utility;
using NET.POC.Azure;
using NET.POC.AsyncAndAwait;
using NET.POC.Odin.Compute.Common.Domain;
using NET.POC.Odin_POC;

namespace NET.POC
{
    internal class Program
    {
        //Program(int var):base() {
        //    variable = var;
        //}
        static SerialPortStream _listeningPort = null;

        readonly int readonlyValue = 10;
        const int cValue = 5;
        static void Main(string[] args)
        {
            //AzureStorageQueues azureStorageQueues = new AzureStorageQueues();
            //azureStorageQueues.AzureQueueStorage();
            //CLUTroubleShoot();
            //C c = new C();
            //c.GetClassB();

            while (true)
            {
                PlayAudioAsRadioBroadcast.Play();
            }
            //MicroLocationBeaconDataAnalyzer microLocation = new();
            //microLocation.SegregateBeaconDeviceActivations();           
            //AsyncAwait.CallMethod();
            //string input = "374291--*+-";
            //string output = RearrangeExpression(input);
            //Console.WriteLine("Input: " + input);
            //Console.WriteLine("Output: " + output);
            //AsyncAwait.Method2();
            Console.ReadKey();
        }

        static void AltiMetric()
        {
            int a = 10;
            int b = 12;
            int c = a ^ b;
            Console.WriteLine(c);
            Console.WriteLine(true ^ true);

            for (; ; )
                ;
            for (; ; )
            {

            }
        }

        static void StartUpMethods()
        {
            //Employ structEmploy = new Employ();
            //structEmploy.id = 300;
            //User2 user = new User2();
            //Employ1 classEmploy = new Employ1();
            //classEmploy.id = 2;

            //Console.WriteLine(structEmploy.id);
            //Console.WriteLine(classEmploy.id);


            //ChangeClassValue(classEmploy);
            //ChangeStructValue(structEmploy);

            //Console.WriteLine(structEmploy.id);
            //Console.WriteLine(classEmploy.id);

            //User user = new User(10);


            //ITest obj = new Test(new Test());
            //obj.get();
            //CLUTroubleShoot();

            //PrivateConstructor.Method1();
            //PrivateConstructor.Method1();
            //PrivateConstructor.Method1();
            //PrivateConstructor.Method1();
            //PrivateConstructor.Method1();
            //PrivateConstructor.Method1();
            //PrivateConstructor privateConstructor = new PrivateConstructor();
            //PrivateConstructor privateConstructor3 = PrivateConstructor.Method2();
            //privateConstructor.Method3();
            //privateConstructor.Method3();
            //privateConstructor.Method3();
            //PrivateConstructor privateConstructor1 = PrivateConstructor.Method2();
            //privateConstructor1.Method3();
            //privateConstructor1.Method3();
            //privateConstructor1.Method3();
            //Console.WriteLine("Hello, World!");

            //List<Student> studentList = new List<Student>()
            //{
            //    new Student(){ID = 1, Name = "James", Gender = "Male"},
            //    new Student(){ID = 1, Name = "James", Gender = "Male"},
            //    new Student(){ID = 2, Name = "Sara", Gender = "Female"},
            //    new Student(){ID = 3, Name = "Steve", Gender = "Male"},
            //    new Student(){ID = 4, Name = "Pam", Gender = "Female"}
            //};           
            //EN6040();
            //ConvertJSONStructure convertJSONStructure = new ConvertJSONStructure();
            //convertJSONStructure.JSONFormatConvert();
            //ExportProject exportProject = new ExportProject();
            //exportProject.GetIntentInfosFromCLU();
            //RegexIterate regexBlock = new();
            //regexBlock.GetCountOfElement();
            //GetCountOfElement();
            //GetCountOfElementUsingDictionary();

            //ActivationCalculator activationCalculator = new();
            //activationCalculator.GetActivationCount();
            //ProdIssueTroubleshooter prodIssueTroubleshooter = new ProdIssueTroubleshooter();
            //prodIssueTroubleshooter.GetActivationCount();
            //UploadZipFileToAzureBlob.UploadZipFile();
            ////transmitter.Connect();
            //ConfigureListeningComPort("COM1");
        }

        static string RearrangeExpression(string input)
        {
            StringBuilder output = new StringBuilder();
            List<int> digits = new List<int>();
            List<string> specialChars = new List<string>();

            // Extract digits from the input
            foreach (char c in input)
            {
                if (char.IsDigit(c))
                {
                    digits.Add(c - '0');
                }
                else
                {
                    specialChars.Add(c.ToString());
                }
            }

            // Append digits with proper operators to the output string
            for (int i = 0; i < digits.Count; i++)
            {
                output.Append(digits[i]);

                for (int j = i; j <= i && j < specialChars.Count; j++)
                {
                    output.Append(specialChars[j]);
                }
            }

            return output.ToString();
        }


        #region CLU TroubleShoot
        public static void CLUTroubleShoot()
        {
            // Specify the folder path
            string folderPath = @"D:\Prod Issues\Shawn Machine CLU\Log backup for CLU - Do not delete\Log backup for CLU - Do not delete\interpreter";
            string systemInputFolderPath = @"D:\Prod Issues\Shawn Machine CLU\Log backup for CLU - Do not delete\Log backup for CLU - Do not delete\system input";
            List<string> jsonValues = new List<string>();

            // Check if the folder exists
            if (Directory.Exists(folderPath))
            {
                // Create a list to store extracted JSON values

                // Get all files in the specified folder
                string[] files = Directory.GetFiles(folderPath);

                // Iterate through each file
                foreach (string file in files)
                {
                    // Read the lines of the file
                    string[] lines = File.ReadAllLines(file);

                    // Print lines starting with "intentPredictionResponse {"kind":"
                    Console.WriteLine($"File: {file}");
                    foreach (string line in lines)
                    {
                        if (line.Contains("intentPredictionResponse {\"kind\":"))
                        {
                            Console.WriteLine(line.Substring(0, 29));
                            // Extract JSON value from the line
                            int startIndex = line.IndexOf("{");
                            int endIndex = line.LastIndexOf("}}}") + 3;

                            if (startIndex != -1 && endIndex != -1)
                            {
                                string jsonValue = line.Substring(startIndex, endIndex - startIndex);
                                //Console.WriteLine(jsonValue);
                                //Console.WriteLine(new string('-', 50));
                                jsonValues.Add(jsonValue);

                                PrintIntentResult(jsonValue);
                                Console.WriteLine(new string('-', 50));

                                // Extract GUID after "DEBUG" in the line
                                string guidPattern = @"\[([^\]]+)\]";
                                Match guidMatch = Regex.Match(line, guidPattern);

                                if (guidMatch.Success)
                                {
                                    string capturedGuid = guidMatch.Groups[1].Value;

                                    // Store the GUID for later use
                                    //jsonValues.Add(capturedGuid);

                                    // Now search for the GUID in another set of files
                                    //SearchAndPrintLines(systemInputFolderPath, capturedGuid);
                                }

                            }
                            //Console.WriteLine(line);
                        }
                    }
                    // Add a separator between files
                    Console.WriteLine(new string('-', 50));

                    // Convert the list to a JSON array
                    //JArray jsonArray = JArray.Parse("[" + string.Join(",", jsonValues) + "]");

                    //// Print the JSON array
                    //Console.WriteLine(jsonArray.ToString());
                }
            }
            else
            {
                Console.WriteLine("Specified folder does not exist.");
            }

            //// Convert the list to a JSON array
            //JArray jsonArray = JArray.Parse("[" + string.Join(",", jsonValues) + "]");

            //// Print the JSON array
            //Console.WriteLine(jsonArray.ToString());

            Console.WriteLine("Press any key to exit...");
        }

        static void PrintIntentResult(string jsonValue)
        {
            JObject jsonObject = JObject.Parse(jsonValue);

            string query = (string)jsonObject["result"]["query"];
            Console.WriteLine($"query: {query}");
            // Print "topIntent" value
            string topIntent = (string)jsonObject["result"]["prediction"]["topIntent"];
            Console.WriteLine($"topIntent: {topIntent}");
            // Print entities from "entities" category
            JArray entities = (JArray)jsonObject["result"]["prediction"]["entities"];
            int count = 0;
            foreach (JObject entity in entities)
            {
                count++;
                string category = (string)entity["category"];
                string text = (string)entity["text"];
                Console.WriteLine($"{category}: {text}");
            }
            if (count == 1)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Entities not matched properly");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        #endregion CLU TroubleShoot

        static void SearchAndPrintLines(string folderPath, string capturedGuid)
        {
            // Get all files in the specified folder
            string[] files = Directory.GetFiles(folderPath);

            // Iterate through each file
            foreach (string file in files)
            {
                // Read the lines of the file
                string[] lines = File.ReadAllLines(file);

                // Print lines containing "After removing remove space between number: Text=" and the captured GUID
                foreach (string line in lines)
                {
                    if (line.Contains(capturedGuid) && line.Contains($"After removing remove space between number: Text="))
                    {

                        string searchText = $"After removing remove space between number: Text=";
                        int index = line.IndexOf(searchText);

                        if (index != -1)
                        {
                            // Extract and print the text after the specified search text
                            string textAfterSearch = line.Substring(index + searchText.Length).Trim();
                            Console.WriteLine($"File: {file}");
                            Console.WriteLine($"Text after search:");
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine(textAfterSearch);
                            Console.WriteLine(new string('-', 50));
                        }

                        //Console.WriteLine($"File: {file}");
                        //Console.WriteLine(line);
                        //Console.WriteLine(new string('-', 50));
                    }
                }
            }
        }

        public static void GetCountOfElement()
        {
            List<string> inputs = new List<string>()
            {
                    "Orange", "Apple", "Banana", "Banana", "Apple"
            };

            List<string> uniqueInput = new List<string>();

            int elementCount = 0;
            int count = inputs.Count;

            for (int i = 0; i < count; i++)
            {
                if (!uniqueInput.Contains(inputs[i]))
                {
                    for (int j = 0; j < count; j++)
                    {
                        if (inputs[i] == inputs[j])
                        {
                            elementCount++;
                        }
                    }
                    uniqueInput.Add(inputs[i]);
                }
                if (elementCount > 0)
                {
                    Console.WriteLine(inputs[i] + ":" + elementCount);
                }
                elementCount = 0;
            }
        }


        public static void GetCountOfElementUsingDictionary()
        {
            string[] input = { "Orange", "Apple", "Banana", "Apple", "Banana" };

            Dictionary<string, int> keyValuePairs = new Dictionary<string, int>();

            foreach (string i in input)
            {
                if (keyValuePairs.ContainsKey(i))
                {
                    keyValuePairs[i] += 1;
                }
                else
                {
                    keyValuePairs[i] = 1;
                }

                //_ = keyValuePairs.ContainsKey(i) ? keyValuePairs[i] += 1 : keyValuePairs[i] = 1;
            }


            foreach (var entry in keyValuePairs)
            {
                Console.WriteLine($"{entry.Key}: {entry.Value}");
            }
        }


        static string LongestWord(string sen)
        {
            // Remove punctuation and split the string into words
            string[] words = Regex.Split(sen, @"\W+");

            // Initialize variables to keep track of the longest word and its length
            string longestWord = "";
            int maxLength = 0;

            foreach (string word in words)
            {
                // Remove any characters that appear in the ChallengeToken
                string cleanedWord = RemoveChallengeTokenChars(word, "hdwfs93u6e8");

                if (cleanedWord.Length > maxLength)
                {
                    maxLength = cleanedWord.Length;
                    longestWord = cleanedWord;
                }
            }

            if (longestWord.Length == 0)
            {
                return "EMPTY";
            }


            return longestWord;
        }

        static string RemoveChallengeTokenChars(string word, string challengeToken)
        {
            StringBuilder cleanedWord = new StringBuilder();

            foreach (char c in word)
            {
                if (!challengeToken.Contains(char.ToLower(c)))
                {
                    cleanedWord.Append(c);
                }
            }

            return cleanedWord.ToString();
        }

        static void Main1(string[] args)
        {
            string input1 = "fun&!! time";
            string input2 = "I love evol dogs";

            string input = Console.ReadLine();
            Console.WriteLine(LongestWord(input));

            string input3 = Console.ReadLine();
            Console.WriteLine(LongestWord(input3));

            //string output1 = LongestWord(input1);
            //string output2 = LongestWord(input2);

            //Console.WriteLine("Input 1: " + output1);
            //Console.WriteLine("Final Output 1: " + output1);
            //Console.WriteLine("Input 2: " + output2);
            //Console.WriteLine("Final Output 2: " + output2);
            Console.Read();
        }

    }
    
}