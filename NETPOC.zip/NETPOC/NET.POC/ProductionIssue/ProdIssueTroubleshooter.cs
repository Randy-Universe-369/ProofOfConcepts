﻿using NET.POC.Enumerations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NET.POC.ProductionIssue
{
    public class ProdIssueTroubleshooter
    {
        Dictionary<string, ActivationReport> keyValuePairs = new Dictionary<string, ActivationReport>();
        Dictionary<int, int> repeaterCaptureCount = new Dictionary<int, int>();

        public void GetActivationCount()
        {
            string[] files = Directory.GetFiles(@"D:\Prod Issues\Samaritan Bethany\New folder\New folder");
            // Use a for loop to iterate through files
            for (int i = 1; i < files.Length-1; i++)
            {
                string filePath = $@"D:\Prod Issues\Samaritan Bethany\New folder\New folder\OdinEventProcessorService.txt.{i}";
                string[] lines = File.ReadAllLines(filePath);
                string activationTriggeredFrom = string.Empty;
                int totalActivationCount = 0;
                List<EchoStreamData> echoStreamDataInfos = new();
                List<string> globalTrackingGuids = new();
                var guidRegex = new Regex(@"[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}");

                // Iterate through each log line
                for (int lin = 0; lin < lines.Length; lin++)
                {
                    string line = lines[lin];
                    string[] initiatorGuids = new string[]
                    {
                        "B43A2AFE-759B-44BB-922D-01A5D0549FBD",
                        "56C725ED-4CC8-46A7-9648-0F789CEC541E",
                        "E2EE8F05-8828-4274-8CEF-115C78DB5697",
                        "0DF0F1EE-7D14-43DD-9EBF-18EDB017EFE7",
                        "BEB888E0-E13C-45BD-820C-1ABAC4EAD726",
                        "280D7B3D-3087-4189-8ABD-208C67457573",
                        "12F46BDB-18E4-4483-B463-2E936DB22920",
                        "DC3D3175-34E4-4E19-A3CE-30E4FA594105",
                        "0702F86A-3CFA-4372-8B97-3DCF7D8D4C67",
                        "9D827AC1-DAF0-45D0-8309-40D8AA179312",
                        "E47BD18A-759C-44D9-91D5-4A54E1CA918A",
                        "2878D1E5-9AD9-4869-86CB-570CAC70839B",
                        "62D82A24-370C-4787-8947-592599E7E606",
                        "D3E69AEF-3084-4709-8188-5B3F4A315821",
                        "34BDB2C9-F358-4BF4-AFAA-67F28D3026D0",
                        "BDFA6E9D-D9E2-4559-B74A-758ACFFBFB6F",
                        "2532BC96-86A6-47A1-B1B9-82A2FDBF8854",
                        "5AA738F5-B8E1-4EEE-9E60-8A195986956A",
                        "677F68F5-8ECC-439A-B1CF-95F71A303191",
                        "938ECE93-DDDE-478D-B044-971C6A61ABE3",
                        "85884D66-7AEE-453A-BF6B-ADEE7C15E59A",
                        "696DD2DE-8ED3-4E98-97C2-BC95427174FE",
                        "7F8D9F34-2E4A-476C-A202-C5FE23EE980E",
                        "7125643A-36DE-4A54-87F2-C6FF70F62832",
                        "C6C517FC-99B4-4DE3-BE72-C78AEA7BDBB3",
                        "2E6B1A4C-9F13-4A03-A81B-CA308ED7D533",
                        "EE911559-9989-4D3A-BA04-CAB818624DB4",
                        "69924ECE-075E-424C-B553-CD9FB380FA22",
                        "69E80749-D9D6-4294-8C27-E3AC1EFAC0F7",
                        "0E400E77-3274-4EDB-8073-E4F3C2D7745B",
                        "C8B694DF-A092-4051-8A0E-E5922E81EBC5",
                        "8566E7A0-2463-4EFD-8539-FE56C042042D"
                    };
                    
                    //bool isInitiatorGuidExist = line.Contains(initiatorGuid.ToLower());
                    bool isInitiatorGuidExist = initiatorGuids.Any(guid => line.Contains(guid.ToLower()));
                    if (isInitiatorGuidExist)
                    {
                        // Extract the first GUID portion
                        Match guidMatch = guidRegex.Match(line);
                        if (guidMatch.Success)
                        {
                            string firstGuid = guidMatch.Value;
                            if (globalTrackingGuids != null && globalTrackingGuids.Where(x => x == firstGuid).Count() == 0)
                            {
                                globalTrackingGuids.Add(firstGuid);
                            }
                            //// Check if the line contains the specified error message
                            //if (line.Contains("Error transmitting bytes:"))
                            //{
                            //    // Check if there are any subsequent lines with the same GUID
                            //    bool hasSubsequentLines = CheckForSubsequentLines(lines, i + 1, firstGuid);

                            //    if (!hasSubsequentLines)
                            //    {
                            //        Console.WriteLine($"No other lines with the same GUID ({firstGuid}) after the error.");
                            //    }
                            //}
                        }
                    }

                }

                for (int li = 0; li < lines.Length; li++)
                {
                    // Extract the first GUID portion
                    Match guidMatch = guidRegex.Match(lines[li]);
                    if (guidMatch.Success)
                    {
                        string firstGuid = guidMatch.Value;
                        if (globalTrackingGuids.Contains(firstGuid))
                        {
                            Console.WriteLine(lines[li]);

                            // Check if the line contains the specified error message
                            if (lines[li].Contains("Error in "))
                            {
                                // Check if there are any subsequent lines with the same GUID
                                bool hasSubsequentLines = CheckForSubsequentLines(lines, li + 1, firstGuid);

                                if (!hasSubsequentLines)
                                {
                                    Console.WriteLine($"No other lines with the same GUID ({firstGuid}) after the error.");
                                }
                            }
                        }
                    }
                }

                Console.WriteLine("Completed Path of ");
                Console.WriteLine(filePath);
                Console.WriteLine("\n\n]n");
                Console.WriteLine(totalActivationCount);
            }




        }


        static bool CheckForSubsequentLines(string[] logLines, int startIndex, string guid)
        {
            for (int i = startIndex; i < logLines.Length; i++)
            {
                string line = logLines[i];

                // Extract the first GUID portion
                Match guidMatch = Regex.Match(line, @"[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}");
                if (guidMatch.Success)
                {
                    string currentGuid = guidMatch.Value;

                    // Check if the current line has the same GUID
                    if (currentGuid == guid)
                    {
                        // There is another line with the same GUID after the error
                        return true;
                    }
                }
            }

            // No other lines with the same GUID after the error
            return false;
        }

        private void ProcessActivationReport(List<EchoStreamData> echoStreamDataInfos, string activationTriggeredFrom)
        {

            //ActivationReport activationReport = new();

            var firstHopDeviceUniqueCount = echoStreamDataInfos.DistinctBy(x => x.FirstHopUniqueId).ToList().Select(x => x.FirstHopUniqueId);

            //activationReport.ActivationCount = echoStreamDataInfos.Count();
            //activationReport.RepeaterCount = firstHopDeviceUniqueCount.Count();
            //activationReport.Repeaters = new List<int>();
            //activationReport.Repeaters.AddRange(firstHopDeviceUniqueCount);

            //keyValuePairs[activationTriggeredFrom] = activationReport;

            foreach (EchoStreamData echoStream in echoStreamDataInfos)
            {
                //if(echoStream.SignalLevel > 30)
                //{
                if (repeaterCaptureCount.ContainsKey(echoStream.FirstHopUniqueId))
                {
                    repeaterCaptureCount[echoStream.FirstHopUniqueId] += 1;
                }
                else
                {
                    repeaterCaptureCount[echoStream.FirstHopUniqueId] = 1;
                }
                //}


                //_ = keyValuePairs.ContainsKey(i) ? keyValuePairs[i] += 1 : keyValuePairs[i] = 1;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{activationTriggeredFrom}");
            Console.WriteLine("---------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Activation Type: {echoStreamDataInfos[0].ActivationType}\n");
            Console.WriteLine($"Activation Count: {echoStreamDataInfos.Count()}\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Captured Repeater Count: {firstHopDeviceUniqueCount.Count()}\n");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Repeater Details:");
            Console.WriteLine("---------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            foreach (var entry in repeaterCaptureCount)
            {
                Console.WriteLine($"{GetRepeaterName(entry.Key)} - {entry.Key}: {entry.Value}");
            }
            Console.WriteLine("\n");
        }

        private bool CheckLastActivationIsDifferThanCurrent(List<EchoStreamData> echoStreamDataInfos, EchoStreamData echoStreamData)
        {
            if (echoStreamDataInfos[echoStreamDataInfos.Count - 1].ActivationType == echoStreamData.ActivationType)
            {
                return true;
            }
            return false;
        }

        private EchoStreamData DecodeHexData(string receivedHexData)
        {
            byte[] messageData = Enumerable.Range(0, receivedHexData.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(receivedHexData.Substring(x, 2), 16))
                             .ToArray();
            //byte[] messageData = Encoding.ASCII.GetBytes("7212B2B95650012F060300013E1A010001012A");
            EchoStreamData echoStreamData = new();

            echoStreamData.OriginatorUniqueId = GetUniqueId(messageData, 3);
            echoStreamData.FirstHopDevice = (EchoStreamFirstHopDevice)messageData[6];
            echoStreamData.FirstHopUniqueId = GetUniqueId(messageData, 7);
            echoStreamData.FirstHopRepeaterName = GetRepeaterName(echoStreamData.FirstHopUniqueId);
            echoStreamData.TraceCount = messageData[10];
            echoStreamData.HopCount = messageData[11];
            //It is a binary ("Short") message
            echoStreamData.ApplicationStatusFlags = (EchoStreamApplicationStatusFlags)messageData[14];
            echoStreamData.PrimaryStatusFlags = (EchoStreamPrimaryStatusFlags)messageData[15];
            echoStreamData.SignalLevel = messageData[16];
            echoStreamData.SignalMargin = messageData[17];
            echoStreamData.ActivationType = GetActivationType(echoStreamData.ApplicationStatusFlags, echoStreamData.PrimaryStatusFlags);

            //Console.WriteLine($"Name: {name}");
            //Console.WriteLine($"Activation Type: {GetActivationType(echoStreamData.ApplicationStatusFlags, echoStreamData.PrimaryStatusFlags)}");
            //Console.WriteLine($"First Hop Device: {echoStreamData.FirstHopDevice}");
            //Console.WriteLine($"First Hop Repeater: {echoStreamData.FirstHopRepeaterName}");
            //Console.WriteLine($"Serial Receiver Number: {echoStreamData.FirstHopUniqueId}");
            //Console.WriteLine($"Hop Count: {echoStreamData.HopCount}");
            ////GetActivationType(bytes);

            return echoStreamData;
        }

        private static string GetRepeaterName(int serialNumber)
        {
            return serialNumber switch
            {
                3081193 => "Repeater 1",
                2974235 => "Repeater 2",
                3081799 => "Repeater 3",
                3081345 => "Repeater 4",
                3081731 => "Repeater 5",
                3079702 => "Repeater 6",
                3081554 => "Repeater 7",
                3081530 => "Repeater 8",
                3081347 => "Repeater 9",
                3081034 => "Repeater 10",
                3081517 => "Repeater 11",
                3081556 => "Repeater 12",
                3081553 => "Repeater 13",
                _ => "RF Gateway"
            };
        }

        private static string GetActivationType(EchoStreamApplicationStatusFlags ApplicationStatusFlags, EchoStreamPrimaryStatusFlags PrimaryStatusFlags)
        {
            if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.PrimaryAlarm && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Unset)
            {
                return "First Activation";
            }
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Unset)
            {
                return "Clear with First Activation";
            }//Segregating bytes with EN1223S so it has OO OO with first activation itself, so consider reset is a first activation
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.NoChange)
            {
                return "CheckIn";
            }
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Reset)
            {
                return "Reset As Clear";
            }

            return "Unknown";
            //return (EchoStreamFirstHopDevice)messageData[6];            
        }


        private static int GetUniqueId(byte[] messageData, int startIndex)
        {

            //Create an array to copy in the uid data from the message data array
            byte[] uidData = new byte[4];

            //The start position of the destination array is 1 because we're copying 3 bytes into a 4 byte integer
            Array.Copy(messageData, startIndex, uidData, 1, 3);

            //Determine if this is a little endian machine and reverse the uid data array if so
            if (BitConverter.IsLittleEndian)
            {
                //reverse the order of the uid data array
                uidData = uidData.Reverse().ToArray();
            }

            //Get the unique id
            int uniqueId = BitConverter.ToInt32(uidData, 0);

            //return the result
            return uniqueId;
        }
    }



    public class ActivationReport
    {
        public int ActivationCount { get; set; }
        public int ClearCount { get; set; }
        public int RepeaterCount { get; set; }
        public int HopCount { get; set; }
        public List<int> Repeaters { get; set; }

    }

    public class EchoStreamData
    {
        public int OriginatorUniqueId { get; set; }
        public string FirstHopRepeaterName { get; set; }
        public string ActivationType { get; set; }
        public EchoStreamFirstHopDevice FirstHopDevice { get; set; }
        public int FirstHopUniqueId { get; set; }
        public byte TraceCount { get; set; }
        public byte HopCount { get; set; }
        public EchoStreamApplicationStatusFlags ApplicationStatusFlags { get; set; } //This is also known as STAT1
        public EchoStreamPrimaryStatusFlags PrimaryStatusFlags { get; set; } //This is also known as STAT0

        public byte SignalLevel { get; set; }
        public byte SignalMargin { get; set; }

    }
}

