﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Core;
using Azure.Core.Serialization;
using Azure.AI.Language.Conversations.Authoring;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;

namespace NET.POC.CLU
{
    internal class ExportProject
    {
        public ExportProject()
        {
            
        }

        static ExportProject()
        {
            
        }
      

        public CLUAuthoringModelEvalResponse GetIntentInfosFromCLU()
        {
            CLUAuthoringModelEvalResponse cluAuthoringModelEvalResponse = new CLUAuthoringModelEvalResponse();
            try
            {
                string projectName= "CarliesInventory";
                string modelName = "SageDeployment";
                string endpoint = $"https://onelanguageserviceinstance.cognitiveservices.azure.com/language/authoring/analyze-conversations/projects/CarliesInventory_1/models/test_train/evaluation/result?api-version=2023-04-01&stringIndexType=Utf16CodeUnit&maxpagesize=1000";

            //https://onelanguageserviceinstance.cognitiveservices.azure.com/language/authoring/analyze-conversations/projects/CarliesInventory_1/models/test_train/evaluation/result?stringIndexType=Utf16CodeUnit&api-version=2023-04-01&maxpagesize=1000
                //Create a new HTTP client
                using (var client = new HttpClient())
                {
                    //Create the url for the server                    
                    //client.DefaultRequestHeaders.Accept.Clear();
                    //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "24d3179f296e410fa1e188e2a5c011cd");
                    //client.DefaultRequestHeaders.Add("Content-Type", "application/json");

                    //string apiUrl = string.Format(endpoint, projectName, modelName);
                    //Get the rtu device type- allow status bits synchronously
                    HttpResponseMessage response = client.GetAsync(endpoint).Result;

                    //Check if we were successful, if so, deserialize, otherwise throw execptions
                    if (response.IsSuccessStatusCode)
                    {
                        //Get the rtu device type- allow status bits synchronously
                        string jsonResponse = response.Content.ReadAsStringAsync().Result;
                        SegregateIntents(jsonResponse);
                        cluAuthoringModelEvalResponse = JsonConvert.DeserializeObject<CLUAuthoringModelEvalResponse>(jsonResponse);
                    }
                }

            }
            catch (Exception ex)
            {

            }
            return cluAuthoringModelEvalResponse;
        }


        public void SegregateIntents(string jsonString)
        {
            // Replace this with your JSON string or read it from a file
            //string jsonString = @"{ ... }";

            // Deserialize the JSON string
            var jsonObject = JsonConvert.DeserializeObject<JObject>(jsonString);

            // Create a dictionary to store intents and associated utterances
            var intentsDictionary = new Dictionary<string, List<string>>();

            // Loop through each item in the "value" array
            foreach (var item in jsonObject["value"])
            {
                // Extract intent and text from the item
                string intent = item["intentsResult"]["predictedIntent"].ToString();
                string text = item["text"].ToString();

                // Check if the intent is already in the dictionary
                if (intentsDictionary.ContainsKey(intent))
                {
                    // If yes, add the utterance to the existing list
                    intentsDictionary[intent].Add(text);
                }
                else
                {
                    // If no, create a new list with the current utterance
                    intentsDictionary[intent] = new List<string> { text };
                }
            }

            // Print the results
            foreach (var kvp in intentsDictionary)
            {
                Console.WriteLine($"Intent: {kvp.Key}");
                Console.WriteLine("Utterances:");
                foreach (var utterance in kvp.Value)
                {
                    Console.WriteLine($"  - {utterance}");
                }
                Console.WriteLine();
            }
        }
    }



    public class CLUAuthoringModelEvalResponse
    {
        public List<CLUAuthoringModelEvalResponseValue> value { get; set; }
    }

    public class CLUAuthoringModelEvalResponseValue
    {
        public string text { get; set; }
        public string language { get; set; }

        public CLUEntityResult entityResult { get; set; }

        public CLUIntentResult intentResult { get; set; }


    }

    public class CLUEntityResult
    {
        public List<CLUEntity> expectedEntities { get; set; }
        public List<CLUEntity> predictedEntities { get; set; }
    }

    public class CLUEntity
    {
        public string category { get; set; }
        public int offset { get; set; }
        public int length { get; set; }
    }

    public class CLUIntentResult
    {
        public string expectedIntent { get; set; }
        public string predictedIntent { get; set; }
    }

}
