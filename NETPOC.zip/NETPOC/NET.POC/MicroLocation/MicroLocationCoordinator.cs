﻿using log4net;
using log4net.Config;
using Microsoft.Extensions.Configuration;
using Microsoft.ML;
using Microsoft.ML.Data;
using NET.POC.Enumerations;
using NET.POC.Odin.Compute.Common.Domain;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace NET.POC.MicroLocation
{
    internal class MicroLocationCoordinator
    {
        #region variables

        public static MicroLocationCoordinator Instance
        {
            get
            {
                return _instance;
            }
        }

        private static readonly MicroLocationCoordinator _instance = new MicroLocationCoordinator();

        //For writing to signal and status logs
        private readonly ILog _microlocationSignalLogger;
        private readonly ILog _microlocationPredictionLogger;
        private readonly ILog _microlocationStatusLogger;

        private string _logFolderLocation;
        private string _logFileName;
        private string _modelFileName;
        private double _trainingPercentage = .8;
        private int _minimumTrainingDatapoints;
        private double _modelRebuildIntervalMs;
        private List<string> _endpointSerialNumbers;
        //ML Context
        private MLContext _mlContext = new MLContext();
        //LightGBM Model
        private ITransformer _lightGbmModel;

        private Stopwatch _stopwatch = new Stopwatch();
        private Dictionary<uint, int> _labelEncodings = new Dictionary<uint, int>();

        //For predictions
        private Dictionary<int, string> _beaconLocationLookup = new Dictionary<int, string>();
        //For combining rapidly sent messages
        private Dictionary<int, AverageRepeaterDataList> _lastOriginiatorUniqueIdAverageRepeaterData = new Dictionary<int, AverageRepeaterDataList>();
        private Dictionary<int, DateTime> _lastOriginiatorUniqueIdReceivedDatetime = new Dictionary<int, DateTime>();

        public List<string> repeaters = new List<string> { "3081193", "2974235", "3081799", "3081345", "3081731", "3079702", "3081554", "3081530", "3081347", "3081034", "3081517", "3081556", "3081553" };
        public Dictionary<int, string> locations = new Dictionary<int, string>
        {
            { 3166259, "East Stairwell" },
            { 3171071, "Room 106" },
            { 3167104, "Northwest Stairwell" },
            { 3168472, "Room 111" },
            { 3190247, "Room 113" },
            { 3166257, "Room 112" },
            { 3224894, "Room 109" },
            { 3224895, "Women's Bathroom" },
            { 3168682, "Front Lobby" },
            { 3222454, "Dining Room West" },
            { 3168473, "Dining Room East" },
            { 3223802, "Room 116" },
            { 3222460, "Front Entry" },
            { 3224892, "Room 105A" },
            { 3167102, "Room 118" },
            { 3243897, "Room 115" },
            { 3168708, "Room 100" },
            { 3220783, "Room 104" },
            { 3165475, "Room 110" },
            { 3221687, "Room 105" },
            { 3168463, "Men's Restroom" },
            { 3225370, "Room 114" },
            { 3169894, "Room 103" },
            { 3237923, "Room 107" },
            { 3171069, "Southeast Stairwell" },
            { 3190768, "Activity Room" },
            { 3237930, "Salon" },
            { 3685269, "West Stairwell" },
            { 3221908, "Room 102" },
            { 3230118, "Room 101" }
        };

        public static object ModelFilePadlock
        {
            get
            {
                return _modelFilePadlock;
            }
        }

        //Padlock for thread safety when calling model file
        private static readonly object _modelFilePadlock = new object();
        #endregion


        MicroLocationCoordinator()
        {
            // Load appsettings.json
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();

            // Configure log4net
            var log4NetSection = config.GetSection("Log4Net");
            var log4NetXml = ConvertToXmlElement(log4NetSection);
            var repository = LogManager.GetRepository(System.Reflection.Assembly.GetEntryAssembly());
            XmlConfigurator.Configure(repository, log4NetXml);


            //log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo("log4net.config"));
            _microlocationSignalLogger = LogManager.GetLogger("MicrolocationSignalLog");
            _microlocationPredictionLogger = LogManager.GetLogger("MicrolocationPredictionLog");
            _microlocationStatusLogger = LogManager.GetLogger("MicrolocationStatusLog");

            //Get necessary filepaths
            _logFolderLocation = @"C:\Temp\Log4Net\Microlocation\";
            _logFileName = @"MicrolocationLog.csv";
            _modelFileName = @"C:\\Temp\\model.zip";

            //Get serial numbers of repeaters and receivers
            _endpointSerialNumbers = repeaters;
            _beaconLocationLookup = locations;
        }

        public void BuildModel()
        {
            try
            {

                _microlocationStatusLogger.Info("Rebuilding model...");
                _stopwatch.Start();
                (List<DataPoint> trainingData, List<DataPoint> testingData) = SplitTrainTest();

                //Get count of unique training labels
                int uniqueTrainingLabelsCount = new HashSet<uint>(from x in trainingData select x.Label).Count;

                //Verify microlocation has enough data to proceed
                if (trainingData.Count <= 2500 || uniqueTrainingLabelsCount <= 1)
                {
                    _microlocationStatusLogger.Warn($"Not enough data to implement microlocation: {trainingData.Count}/{_minimumTrainingDatapoints} training datapoints exist, {uniqueTrainingLabelsCount} unique labels.");
                    //IsReadyForPrediction = false;
                    _stopwatch.Stop();
                    _stopwatch.Reset();
                    return;
                }

                //Assign vector length for DataPoints in training data
                int featureCount = trainingData[0].Features.Length;
                SchemaDefinition targetSchema = SchemaDefinition.Create(typeof(DataPoint));
                SchemaDefinition.Column features = targetSchema[1];
                var itemType = ((VectorDataViewType)features.ColumnType).ItemType;
                features.ColumnType = new VectorDataViewType(itemType, featureCount);

                //Format training data
                IDataView formattedTrainingData = _mlContext.Data.LoadFromEnumerable(trainingData, targetSchema);

                //Train model
                var pipeline =
                    _mlContext.Transforms.Conversion.MapValueToKey(outputColumnName: "LabelKey", inputColumnName: "Label")
                    .Append(_mlContext.MulticlassClassification.Trainers.LightGbm(labelColumnName: "LabelKey"))
                    .Append(_mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabelValue", "PredictedLabel"))
                    .AppendCacheCheckpoint(_mlContext);
                ITransformer model = pipeline.Fit(formattedTrainingData);

                _stopwatch.Stop();
                _microlocationStatusLogger.Info($"Model rebuilt in {_stopwatch.ElapsedMilliseconds} ms");
                _stopwatch.Reset();
                _microlocationStatusLogger.Info($"Testing model");
                _stopwatch.Start();

                //Run model on testing data and fetch testing data predictions
                IDataView formattedTestingData = _mlContext.Data.LoadFromEnumerable(testingData, targetSchema);
                IDataView transformedTestingData = model.Transform(formattedTestingData);
                List<Prediction> testingPredictions = _mlContext.Data.CreateEnumerable<Prediction>(transformedTestingData, reuseRowObject: false).ToList();

                _stopwatch.Stop();
                _microlocationStatusLogger.Info($"Model tested in {_stopwatch.ElapsedMilliseconds} ms");
                _stopwatch.Reset();

                //Log details
                LogPredictionDetails(testingPredictions);
                MulticlassClassificationMetrics testingMetrics = _mlContext.MulticlassClassification.Evaluate(transformedTestingData,
                    labelColumnName: "LabelKey", predictedLabelColumnName: "PredictedLabel");
                LogMetrics(testingMetrics);

                //Update model object and mark current time as last successful rebuild
                DataViewSchema modelSchema;

                //Overwrite the old model file and reload _lightGbmModel object
                lock (ModelFilePadlock)
                {
                    _mlContext.Model.Save(model, formattedTrainingData.Schema, _modelFileName);
                    _lightGbmModel = _mlContext.Model.Load(_modelFileName, out modelSchema);
                }
                //IsReadyForPrediction = true;
            }
            catch (System.ArgumentOutOfRangeException e)
            {
                _microlocationStatusLogger.Error($"Column mismatch in MicrolocationLog.csv, file is likely in an incorrect format: {e}");
                //IsReadyForPrediction = false;
            }
            catch (Exception e)
            {
                _microlocationStatusLogger.Error($"Error in MicrolocationCoordinator.BuildModel: {e}");
            }
        }

        static XmlDocument ConvertToXml(IConfigurationSection section)
        {
            var xmlDoc = new XmlDocument();
            var xmlRoot = xmlDoc.CreateElement("log4net");
            xmlDoc.AppendChild(xmlRoot);

            foreach (var child in section.GetChildren())
            {
                var xmlChild = xmlDoc.CreateElement(child.Key);
                xmlChild.InnerText = child.Value;
                xmlRoot.AppendChild(xmlChild);
            }

            return xmlDoc;
        }

        static XmlElement ConvertToXmlElement(IConfigurationSection section)
        {
            var xmlDoc = new XmlDocument();
            var xmlRoot = xmlDoc.CreateElement("log4net");
            xmlDoc.AppendChild(xmlRoot);

            foreach (var child in section.GetChildren())
            {
                var xmlChild = xmlDoc.CreateElement(child.Key);
                xmlChild.InnerText = child.Value;
                xmlRoot.AppendChild(xmlChild);
            }

            return xmlRoot;
        }

        public void Predict(EchoStreamMessage messageToPredict)
        {
            try
            {
                    int prediction = 0;
                    messageToPredict.PredictedNearestOriginatorUniqueId = prediction;

                    int originatorUniqueId = messageToPredict.OriginatorUniqueId;

                    //Handle rapidly sent messages by combining the AverageRepeaterData if less than 5 seconds has passed since the last message
                    if (_lastOriginiatorUniqueIdAverageRepeaterData.ContainsKey(originatorUniqueId) &&
                        (DateTime.UtcNow - _lastOriginiatorUniqueIdReceivedDatetime[originatorUniqueId]).TotalMilliseconds <= 5000)
                    {
                        messageToPredict.AverageRepeaterData.Combine(_lastOriginiatorUniqueIdAverageRepeaterData[originatorUniqueId]);
                    }

                    _lastOriginiatorUniqueIdAverageRepeaterData[originatorUniqueId] = messageToPredict.AverageRepeaterData;
                    _lastOriginiatorUniqueIdReceivedDatetime[originatorUniqueId] = DateTime.UtcNow;

                    //Parse cluster for prediction
                    int[] devicesReceived = messageToPredict.AverageRepeaterData.Select(x => (int)x.FirstHopDeviceUniqueId).ToArray();
                    int productType = messageToPredict.ProductTypeIdentifier;
                    int clusterLength = devicesReceived.Length;
                    int hour = messageToPredict.TimeCreatedUtc.Hour;
                    int dayOfWeek = (int)messageToPredict.TimeCreatedUtc.DayOfWeek;
                    int month = (int)messageToPredict.TimeCreatedUtc.Month;
                    int isWeekday = dayOfWeek == 0 || dayOfWeek == 6 ? 0 : 1;

                    List<float> features = new List<float>()
                    {
                        productType,
                        clusterLength,
                        hour,
                        dayOfWeek,
                        month,
                        isWeekday
                    };

                    //Assure that at least one signal was received by an endpoint in the database
                    bool validSignalFound = false;

                    foreach (string endpoint in _endpointSerialNumbers)
                    {
                        //This endpoint received messages in this cluster, average signal level/margin, take lowest hop count and add to row
                        if (devicesReceived.Contains(Convert.ToInt32(endpoint)))
                        {
                            validSignalFound = true;
                            AverageRepeaterDataItem repeaterData = messageToPredict.AverageRepeaterData.FirstOrDefault(x => x.FirstHopDeviceUniqueId == Convert.ToInt32(endpoint));
                            int averageSignalLevel = (int)System.Math.Round(repeaterData.AverageSignalLevel);
                            int averageSignalMargin = (int)System.Math.Round(repeaterData.AverageSignalMargin);
                            int lowestHopCount = (int)repeaterData.LowestHopCount;
                            //csv formatted features
                            features.AddRange(new float[] { averageSignalLevel, averageSignalMargin, lowestHopCount });
                        }
                        //This endpoint received no messages, populate with blank values
                        else
                        {
                            features.AddRange(new float[] { float.NaN, float.NaN, float.NaN });
                        }
                    }

                    //Predict location if at least one valid signal was received
                    if (validSignalFound == true)
                    {

                        DataPoint predictionObject = new DataPoint(features.ToArray());

                        //Declare feature vector length
                        int featureCount = predictionObject.Features.Length;
                        SchemaDefinition targetSchema = SchemaDefinition.Create(typeof(DataPoint));
                        SchemaDefinition.Column featureSchema = targetSchema[1];
                        var itemType = ((VectorDataViewType)featureSchema.ColumnType).ItemType;
                        featureSchema.ColumnType = new VectorDataViewType(itemType, featureCount);

                        //Train model
                        IDataView formattedPredictors = _mlContext.Data.LoadFromEnumerable(new DataPoint[1] { predictionObject }, targetSchema); //put predictionObject in array to use LoadFromEnumerable
                        IDataView transformedPredictors;

                        //Lock model file while in use
                        lock (ModelFilePadlock)
                        {
                            transformedPredictors = _lightGbmModel.Transform(formattedPredictors);
                        }

                        //Make predictions
                        Prediction[] finalPrediction = _mlContext.Data.CreateEnumerable<Prediction>(transformedPredictors, reuseRowObject: false).ToArray();

                        if (finalPrediction.Length != 1)
                        {
                            throw new Exception($"{finalPrediction.Length} predictions returned, one was expected");
                        }

                        int predictionSerialNumber = (int)finalPrediction[0].PredictedLabelValue;

                        messageToPredict.PredictedNearestOriginatorUniqueId = predictionSerialNumber;

                        string rowToAdd = $"{messageToPredict.OriginatorUniqueId}," +
                            $"{messageToPredict.PredictedNearestOriginatorUniqueId}," +
                            $"{DateTime.UtcNow}";
                        foreach (float feature in features)
                        {
                            rowToAdd += $",{feature}";
                        }
                        _microlocationPredictionLogger.Info(rowToAdd);
                    }
            }
            catch (Exception e)
            {
                _microlocationStatusLogger.Error($"Error in MicrolocationCoordinator.Predict: {e}");
            }
        }

        public void LogBeaconSignalClusterForMicrolocation(EchoStreamData messageToLog)
        {
            try
            {
                //int microlocationTypeCode = _initiatorRepositoryObject.GetMicrolocationTypeCodeBySerialNumber(messageToLog.OriginatorUniqueId);

                //if (microlocationTypeCode == (int)Lookups.MicrolocationType.Beacon)
                //{
                    int originatorUniqueId = messageToLog.OriginatorUniqueId;

                    //Handle rapidly sent messages by combining the AverageRepeaterData if less than 5 seconds has passed since the last message
                    if (_lastOriginiatorUniqueIdAverageRepeaterData.ContainsKey(originatorUniqueId) &&
                        (DateTime.UtcNow - _lastOriginiatorUniqueIdReceivedDatetime[originatorUniqueId]).TotalMilliseconds <= 5000)
                    {
                        messageToLog.AverageRepeaterData.Combine(_lastOriginiatorUniqueIdAverageRepeaterData[originatorUniqueId]);
                    }

                    //Reset values
                    _lastOriginiatorUniqueIdAverageRepeaterData[originatorUniqueId] = messageToLog.AverageRepeaterData;
                    _lastOriginiatorUniqueIdReceivedDatetime[originatorUniqueId] = DateTime.UtcNow;

                    //Parse and log...

                    int isCheckIn = 0;
                    if (messageToLog.ApplicationStatusFlags.HasFlag(EchoStreamApplicationStatusFlags.Unset) &&
                        messageToLog.PrimaryStatusFlags.HasFlag(EchoStreamPrimaryStatusFlags.NoChange))
                    {
                        isCheckIn = 1;
                    }

                    int[] devicesReceived = messageToLog.AverageRepeaterData.Select(x => (int)x.FirstHopDeviceUniqueId).ToArray();
                    int productType = messageToLog.ProductTypeIdentifier;
                    int clusterLength = devicesReceived.Length;
                    int hour = messageToLog.TimeCreatedUtc.Hour;
                    int dayOfWeek = (int)messageToLog.TimeCreatedUtc.DayOfWeek;
                    int month = (int)messageToLog.TimeCreatedUtc.Month;
                    int isWeekday = dayOfWeek == 0 || dayOfWeek == 6 ? 0 : 1;

                    //Convert default columns to csv string
                    string rowToAdd = $"{originatorUniqueId},{isCheckIn},{productType},{clusterLength},{hour},{dayOfWeek},{month},{isWeekday}";

                    //Assure that at least one signal was received by an endpoint in the database
                    bool validSignalFound = false;

                    foreach (string endpoint in _endpointSerialNumbers)
                    {
                        //This endpoint received messages in this cluster, average signal level/margin, take lowest hop count and add to row
                        if (devicesReceived.Contains(Convert.ToInt32(endpoint)))
                        {
                            validSignalFound = true;
                            AverageRepeaterDataItem repeaterData = messageToLog.AverageRepeaterData.FirstOrDefault(x => x.FirstHopDeviceUniqueId == Convert.ToInt32(endpoint));
                            int averageSignalLevel = (int)System.Math.Round(repeaterData.AverageSignalLevel);
                            int averageSignalMargin = (int)System.Math.Round(repeaterData.AverageSignalMargin);
                            int lowestHopCount = (int)repeaterData.LowestHopCount;
                            //csv formatted features
                            rowToAdd += $",{averageSignalLevel},{averageSignalMargin},{lowestHopCount}";
                        }
                        //This endpoint received no messages, populate with blank values
                        else
                        {
                            //Think of as ,null,null,null 
                            rowToAdd += ",,,";
                        }
                    }

                    //Write row to CSV if a valid signal was found
                    if (validSignalFound == true)
                    {
                        _microlocationSignalLogger.Debug(rowToAdd);
                    }
                //}
            }
            catch (Exception e)
            {
                _microlocationStatusLogger.Error($"Error in MicrolocationCoordinator.LogBeaconSignalClusterForMicrolocation: {e}");
            }
        }


        public (List<DataPoint>, List<DataPoint>) SplitTrainTest()
        {
            try
            {
                //Copy file to prevent reading while being written to
                string logFileCopyName = "MicrolocationLogCopy.csv";
                File.Copy(_logFolderLocation + _logFileName, _logFolderLocation + logFileCopyName);

                //Read and delete log copy, parse CSV lines
                List<string> allLines = File.ReadAllLines(_logFolderLocation + logFileCopyName).ToList();
                File.Delete(_logFolderLocation + logFileCopyName);

                //Check if two log files exist
                if (File.Exists(_logFolderLocation + _logFileName + ".1"))
                {
                    File.Copy(_logFolderLocation + _logFileName, _logFolderLocation + logFileCopyName + ".1");
                    allLines.AddRange(File.ReadAllLines(_logFolderLocation + logFileCopyName + ".1").ToList());
                    File.Delete(_logFolderLocation + logFileCopyName + ".1");
                }
                float[][] parsedRows = allLines.Select(x => x.Split(',').Select(y => y == "" ? float.NaN : float.Parse(y)).ToArray()).ToArray();

                //Split data for testing
                int testPerTenRows = (int)(_trainingPercentage * 10);
                int distributionCount = 1;
                List<DataPoint> trainingData = new List<DataPoint>();
                List<DataPoint> testingData = new List<DataPoint>();

                foreach (float[] row in parsedRows)
                {
                    //Encode labels as 1 through n instead of serial numbers
                    float label = row[0];

                    //Label is the first in the list, so it is not added to features
                    //Currently skipping isCheckIn flag
                    float[] features = row.Skip(2).ToArray();

                    //Distribute evenly
                    if (distributionCount <= testPerTenRows)
                    {
                        trainingData.Add(new DataPoint((uint)label, features));
                    }
                    else
                    {
                        testingData.Add(new DataPoint((uint)label, features));
                    }

                    if (distributionCount % 10 == 0)
                    {
                        distributionCount = 0;
                    }
                    distributionCount++;
                }
                return (trainingData, testingData);
            }
            catch (System.IO.IOException e)
            {
                _microlocationStatusLogger.Error($"Could not reconnect to log file, process is likely in use: {e}");
            }
            catch (System.FormatException e)
            {
                _microlocationStatusLogger.Error($"Column mismatch in MicrolocationLog.csv, file is likely in an incorrect format: {e}");
            }
            catch (Exception e)
            {
                _microlocationStatusLogger.Error($"Error in MicrolocationCoordinator.SplitTrainTest: {e}");
            }
            //If reached, an error has occured; disable microlocation functionality to prevent further problems
            //IsReadyForPrediction = false;
            return (new List<DataPoint>(), new List<DataPoint>());
        }

        // Print prediction accuracy diagnosis
        public void LogPredictionDetails(List<Prediction> predictions)
        {
            try
            {
                //actualFirstHopUniqueId has value <predictedFirstHopUniqueId, numberOfTimesPredicted>
                Dictionary<uint, Dictionary<uint, uint>> predictedList = new Dictionary<uint, Dictionary<uint, uint>>();
                foreach (Prediction prediction in predictions)
                {
                    if (!predictedList.ContainsKey(prediction.Label))
                    {
                        predictedList[prediction.Label] = new Dictionary<uint, uint>()
                    {
                        { prediction.PredictedLabelValue, 1}
                    };
                    }
                    else if (predictedList[prediction.Label].ContainsKey(prediction.PredictedLabelValue))
                    {
                        predictedList[prediction.Label][prediction.PredictedLabelValue] += 1;
                    }
                    else
                    {
                        predictedList[prediction.Label][prediction.PredictedLabelValue] = 1;
                    }
                    _labelEncodings[prediction.PredictedLabel] = (int)prediction.PredictedLabelValue;
                }

                _microlocationStatusLogger.Info("CustomerLocationSection beacon test prediction metrics:");
                foreach (var item in predictedList)
                {
                    float correct = 0;
                    float total = 0;

                    //Fetch originatorUniqueId and name of CustomerLocationSection
                    string name = _beaconLocationLookup[(int)item.Key];

                    _microlocationStatusLogger.Info($"\t{name} accuracy:");
                    foreach (KeyValuePair<uint, uint> entry in item.Value)
                    {
                        //Prediction was correct
                        if (entry.Key == item.Key)
                        {
                            _microlocationStatusLogger.Info($"\t\tPredicted correctly {entry.Value} times");
                            correct += entry.Value;
                        }
                        //Prediction was incorrect
                        else
                        {
                            string predicted_name = _beaconLocationLookup[(int)entry.Key];
                            _microlocationStatusLogger.Info($"\t\tPredicted {predicted_name} {entry.Value} times");
                        }
                        total += entry.Value;
                    }
                    _microlocationStatusLogger.Info($"\t{name}: {System.Math.Round((correct / total) * 100, 2)}% accuracy");
                }
            }
            catch (Exception e)
            {
                _microlocationStatusLogger.Error($"Error in MicrolocationCoordinator.LogPredictionDetails: {e}");
            }
        }

        // Print group metrics
        public void LogMetrics(MulticlassClassificationMetrics metrics)
        {
            try
            {
                _microlocationStatusLogger.Info("beacon test model metrics:");
                _microlocationStatusLogger.Info($"\tMicro accuracy: {metrics.MicroAccuracy:F2}");
                _microlocationStatusLogger.Info($"\tMacro accuracy: {metrics.MacroAccuracy:F2}");
                _microlocationStatusLogger.Info($"\tTop K accuracy: {metrics.TopKAccuracy:F2}");
                _microlocationStatusLogger.Info($"\tLog loss: {metrics.LogLoss:F2}");
                _microlocationStatusLogger.Info(metrics.ConfusionMatrix.GetFormattedConfusionTable());
                _microlocationStatusLogger.Info("Key for confusion matrix:");

                foreach (KeyValuePair<uint, int> labelEncoding in _labelEncodings)
                {
                    _microlocationStatusLogger.Info($"Label {labelEncoding.Key - 1} - Serial Number {labelEncoding.Value} - Location {_beaconLocationLookup[labelEncoding.Value]}");
                }
            }
            catch (Exception e)
            {
                _microlocationStatusLogger.Error($"Error in MicrolocationCoordinator.LogMetrics: {e}");
            }
        }


        public class DataPoint
        {
            public uint Label { get; set; }

            //Blank vector will be assigned its size at runtime
            [VectorType()]
            public float[] Features { get; set; }

            //Constructor for model creation and testing
            public DataPoint(uint label, float[] features)
            {
                Label = label;
                Features = features;
            }

            //Constructor for predictions
            public DataPoint(float[] features)
            {
                Features = features;
            }
        }

        //Used to capture predictions.
        public class Prediction
        {
            //original label
            public uint Label { get; set; }

            //predicted label from the model
            public uint PredictedLabel { get; set; }

            public uint PredictedLabelValue { get; set; }

            //likelihood scores for each endpoint
            public float[] Score { get; set; }
        }
    }
}
