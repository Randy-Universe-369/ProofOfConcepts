﻿using log4net;
using Microsoft.Extensions.Logging;
using NET.POC.Enumerations;
using NET.POC.Odin.Compute.Common.Domain;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.MicroLocation
{
    public class MicroLocationBeaconDataAnalyzer
    {
        Dictionary<int, int> repeaterCaptureCount = new Dictionary<int, int>();

        public void SegregateBeaconDeviceActivations()
        {
            string beaconLogFilePath = @"D:\PC\Micro Location\EchoStreamRawDataLog (1)\EchoStreamRawDataLog.txt";
            string[] lines = File.ReadAllLines(beaconLogFilePath);
            string activationTriggeredFrom = string.Empty;
            int totalActivationCount = 0;
            List<EchoStreamData> echoStreamDataInfos = new();

            foreach (string line in lines)
            {
                string[] parts = line.Split(',');

                if (parts.Length >= 1)
                {
                    string dataAfterPM = parts[1];
                    // Pass the data to your method
                    string processedData = dataAfterPM.ToUpper();

                    if (!string.IsNullOrEmpty(dataAfterPM))
                    {
                        EchoStreamData echoStreamData = DecodeHexData(processedData);

                        if (echoStreamDataInfos.Count == 0 || CheckLastActivationIsDifferThanCurrent(echoStreamDataInfos, echoStreamData))
                        {
                            echoStreamDataInfos.Add(echoStreamData);

                        }
                        else
                        {
                            totalActivationCount += echoStreamDataInfos.Count();
                            activationTriggeredFrom = GetBeaconLocationSectionName(echoStreamDataInfos[0].OriginatorUniqueId);
                            if (activationTriggeredFrom != "Not configured as Beacon")
                            {
                                ProcessNewMessagesToPublish(echoStreamDataInfos);
                                //ProcessActivationReport(echoStreamDataInfos, activationTriggeredFrom);
                                repeaterCaptureCount = new Dictionary<int, int>();
                                echoStreamDataInfos = new List<EchoStreamData>
                                {
                                    echoStreamData
                                };
                            }
                            else
                            {
                                echoStreamDataInfos = new List<EchoStreamData>();
                            }
                        }
                    }

                }

            }
        }


        private void ProcessNewMessagesToPublish(List<EchoStreamData> candidateEchoStreamMessagesToPublish)
        {
            foreach (EchoStreamData candidateEchoStreamMessageToPublish in candidateEchoStreamMessagesToPublish)
            {
                //Logger.Instance.LogDebug($"Candidate message to publish: {candidateEchoStreamMessageToPublish.ToXml(false)}");

                //Add average repeater data for micro location
                candidateEchoStreamMessageToPublish.AverageRepeaterData.AddAverage(
                    (uint)candidateEchoStreamMessageToPublish.FirstHopUniqueId,
                    candidateEchoStreamMessageToPublish.SignalLevel,
                    candidateEchoStreamMessageToPublish.SignalMargin,
                    candidateEchoStreamMessageToPublish.HopCount
                    );

                //Set Global Tracking Guid
                Guid globalTrackingGuid = Guid.NewGuid();
                Console.WriteLine(globalTrackingGuid.ToString());
                candidateEchoStreamMessageToPublish.GlobalTrackingGuid = globalTrackingGuid;
                Console.WriteLine($"candidateEchoStreamMessageToPublish Count{candidateEchoStreamMessagesToPublish.Count()}");

                MicroLocationCoordinator.Instance.LogBeaconSignalClusterForMicrolocation(candidateEchoStreamMessageToPublish);

            }

        }


        private void ProcessActivationReport(List<EchoStreamData> echoStreamDataInfos, string activationTriggeredFrom)
        {
            var firstHopDeviceUniqueCount = echoStreamDataInfos.DistinctBy(x => x.FirstHopUniqueId).ToList().Select(x => x.FirstHopUniqueId);

            foreach (EchoStreamData echoStream in echoStreamDataInfos)
            {
                //if(echoStream.SignalLevel > 30)
                //{
                if (repeaterCaptureCount.ContainsKey(echoStream.FirstHopUniqueId))
                {
                    repeaterCaptureCount[echoStream.FirstHopUniqueId] += 1;
                }
                else
                {
                    repeaterCaptureCount[echoStream.FirstHopUniqueId] = 1;
                }
                //}


                //_ = keyValuePairs.ContainsKey(i) ? keyValuePairs[i] += 1 : keyValuePairs[i] = 1;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{activationTriggeredFrom}");
            Console.WriteLine("---------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Activation Type: {echoStreamDataInfos[0].ActivationType}\n");
            Console.WriteLine($"Activation Count: {echoStreamDataInfos.Count()}\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Captured Repeater Count: {firstHopDeviceUniqueCount.Count()}\n");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Repeater Details:");
            Console.WriteLine("---------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            foreach (var entry in repeaterCaptureCount)
            {
                Console.WriteLine($"{GetRepeaterName(entry.Key)} - {entry.Key}: {entry.Value}");
            }
            Console.WriteLine("\n");
        }


        private bool CheckLastActivationIsDifferThanCurrent(List<EchoStreamData> echoStreamDataInfos, EchoStreamData echoStreamData)
        {
            if (echoStreamDataInfos[echoStreamDataInfos.Count - 1].ActivationType == echoStreamData.ActivationType)
            {
                return true;
            }
            return false;
        }

        private EchoStreamData DecodeHexData(string receivedHexData)
        {
            byte[] messageData = Enumerable.Range(0, receivedHexData.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(receivedHexData.Substring(x, 2), 16))
                             .ToArray();
            //byte[] messageData = Encoding.ASCII.GetBytes("7212B2B95650012F060300013E1A010001012A");
            EchoStreamData echoStreamData = new();          

            echoStreamData.OriginatorUniqueId = GetUniqueId(messageData, 3);
            echoStreamData.FirstHopDevice = (EchoStreamFirstHopDevice)messageData[6];
            echoStreamData.FirstHopUniqueId = GetUniqueId(messageData, 7);
            echoStreamData.FirstHopRepeaterName = GetRepeaterName(echoStreamData.FirstHopUniqueId);
            echoStreamData.TraceCount = messageData[10];
            echoStreamData.HopCount = messageData[11];
            //It is a binary ("Short") message
            echoStreamData.ProductTypeIdentifier = messageData[13];
            echoStreamData.TimeCreatedUtc = DateTime.UtcNow;
            echoStreamData.ApplicationStatusFlags = (EchoStreamApplicationStatusFlags)messageData[14];
            echoStreamData.PrimaryStatusFlags = (EchoStreamPrimaryStatusFlags)messageData[15];
            echoStreamData.SignalLevel = messageData[16];
            echoStreamData.SignalMargin = messageData[17];
            echoStreamData.ActivationType = GetActivationType(echoStreamData.ApplicationStatusFlags, echoStreamData.PrimaryStatusFlags);

            //Console.WriteLine($"Name: {name}");
            //Console.WriteLine($"Activation Type: {GetActivationType(echoStreamData.ApplicationStatusFlags, echoStreamData.PrimaryStatusFlags)}");
            //Console.WriteLine($"First Hop Device: {echoStreamData.FirstHopDevice}");
            //Console.WriteLine($"First Hop Repeater: {echoStreamData.FirstHopRepeaterName}");
            //Console.WriteLine($"Serial Receiver Number: {echoStreamData.FirstHopUniqueId}");
            //Console.WriteLine($"Hop Count: {echoStreamData.HopCount}");
            ////GetActivationType(bytes);

            return echoStreamData;
        }

        private static string GetActivationType(EchoStreamApplicationStatusFlags ApplicationStatusFlags, EchoStreamPrimaryStatusFlags PrimaryStatusFlags)
        {
            if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.PrimaryAlarm && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Unset)
            {
                return "First Activation";
            }
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Unset)
            {
                return "First Activation Clear";
            }//Segregating bytes with EN1223S so it has OO OO with first activation itself, so consider reset is a first activation
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.NoChange)
            {
                return "CheckIn";
            }
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Reset)
            {
                return "Reset";
            }
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Tamper)
            {
                return "Tamper";
            }

            return "Unknown";
            //return (EchoStreamFirstHopDevice)messageData[6];            
        }


        private static string GetRepeaterName(int serialNumber)
        {
            return serialNumber switch
            {
                3081193 => "Repeater 1",
                2974235 => "Repeater 2",
                3081799 => "Repeater 3",
                3081345 => "Repeater 4",
                3081731 => "Repeater 5",
                3079702 => "Repeater 6",
                3081554 => "Repeater 7",
                3081530 => "Repeater 8",
                3081347 => "Repeater 9",
                3081034 => "Repeater 10",
                3081517 => "Repeater 11",
                3081556 => "Repeater 12",
                3081553 => "Repeater 13",
                _ => "RF Gateway"
            };
        }


        private static int GetUniqueId(byte[] messageData, int startIndex)
        {

            //Create an array to copy in the uid data from the message data array
            byte[] uidData = new byte[4];

            //The start position of the destination array is 1 because we're copying 3 bytes into a 4 byte integer
            Array.Copy(messageData, startIndex, uidData, 1, 3);

            //Determine if this is a little endian machine and reverse the uid data array if so
            if (BitConverter.IsLittleEndian)
            {
                //reverse the order of the uid data array
                uidData = uidData.Reverse().ToArray();
            }

            //Get the unique id
            int uniqueId = BitConverter.ToInt32(uidData, 0);

            //return the result
            return uniqueId;
        }

        private string GetBeaconLocationSectionName(int serialNumber)
        {
            return serialNumber switch
            {
                3166259 => "East Stairwell",
                3171071 => "Room 106",
                3167104 => "Northwest Stairwell",
                3168472 => "Room 111",
                3190247 => "Room 113",
                3166257 => "Room 112",
                3224894 => "Room 109",
                3224895 => "Women's Bathroom",
                3168682 => "Front Lobby",
                3222454 => "Dining Room West",
                3168473 => "Dining Room East",
                3223802 => "Room 116",
                3222460 => "Front Entry",
                3224892 => "Room 105A",
                3167102 => "Room 118",
                3243897 => "Room 115",
                3168708 => "Room 100",
                3220783 => "Room 104",
                3165475 => "Room 110",
                3221687 => "Room 105",
                3168463 => "Men's Restroom",
                3225370 => "Room 114",
                3169894 => "Room 103",
                3237923 => "Room 107",
                3171069 => "Southeast Stairwell",
                3190768 => "Activity Room",
                3237930 => "Salon",
                3685269 => "West Stairwell",
                3221908 => "Room 102",
                3230118 => "Room 101",
                _ => "Not configured as Beacon"
            };
        }
    }
}
