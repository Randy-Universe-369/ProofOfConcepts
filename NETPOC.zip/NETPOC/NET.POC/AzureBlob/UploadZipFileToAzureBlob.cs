﻿using Azure.Storage.Blobs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.AzureBlob
{
    public class UploadZipFileToAzureBlob
    {
        public static async Task UploadZipFile()
        {
            string connectionString = "DefaultEndpointsProtocol=https;AccountName=odindev001diag;AccountKey=+dKz9P6uZK1E6o2yEVzAjL0+2rvgF5wS2AEVt7AQ3P8Ik408CrQXPM8y1GE31ufKgqgH7sk8yqb+R8E8o0XizQ==;EndpointSuffix=core.windows.net";
            string containerName = "onemobiledesktopappsoftwarepackageversion";

            Console.WriteLine("Enter the Zip file path which you want to upload");
            string zipFilePath = Console.ReadLine();
            Console.WriteLine("Enter the path along with file name you want to store in Azure Blob");
            string blobName = Console.ReadLine();
            //string zipFilePath = "C:\\Users\\Admin\\Downloads\\v3.16.0.1949.zip";
            //string blobName = "v3.16/v3.16.0.1949.zip";

            await UploadZipToBlob(connectionString, containerName, zipFilePath, blobName);
        }


        static async Task UploadZipToBlob(string connectionString, string containerName, string filePath, string blobName)
        {
            var blobServiceClient = new BlobServiceClient(connectionString);
            var blobContainerClient = blobServiceClient.GetBlobContainerClient(containerName);
            var blobClient = blobContainerClient.GetBlobClient(blobName);

            Console.WriteLine($"Uploading {filePath} to {blobContainerClient.Uri}/{blobClient.Name}");

            using (var fileStream = File.OpenRead(filePath))
            {
                await blobClient.UploadAsync(fileStream, true);
                fileStream.Close();
            }

            Console.WriteLine($"Upload completed.");
        }
    }
}
