﻿using Microsoft.Extensions.Logging;
using NET.POC.Enumerations;
using NET.POC.Odin.Compute.Common.Domain;
using RJCP.IO.Ports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Transmitter
{
    public class ActivationCalculator
    {


        Dictionary<string, ActivationReport> keyValuePairs = new Dictionary<string, ActivationReport>();
        Dictionary<int, int> repeaterCaptureCount = new Dictionary<int, int>();

        public void GetActivationCount()
        {
            string filePath = @"D:\PC\Micro Location\EchoStreamRawDataLog (1)\EchoStreamLocatableActivationRawDataLog.txt";
            string[] lines = File.ReadAllLines(filePath);
            string activationTriggeredFrom = string.Empty;
            int totalActivationCount = 0;
            List<EchoStreamData> echoStreamDataInfos = new();

            foreach (string line in lines)
            {
                string[] parts = line.Split(',');

                if (parts.Length >= 3)
                {
                    activationTriggeredFrom = parts[2];
                    //Console.WriteLine($"Activity Room: {activationTriggeredFrom}");
                }

                //if (keyValuePairs.ContainsKey(activationTriggeredFrom))
                //{

                //}
                //else
                //{
                //    keyValuePairs[activationTriggeredFrom] = new ActivationReport();
                //}

                // Find the index of "PM,"
                //int pmIndex = line.IndexOf("PM,", StringComparison.OrdinalIgnoreCase);

                // If "PM," is found, get the data after it
                if (parts.Length >= 4)
                {
                    //string dataAfterPM = line.Substring(pmIndex + 3); // 3 is the length of "PM,"
                    string dataAfterPM = parts[4];
                    // Pass the data to your method
                    string processedData = dataAfterPM.ToUpper();

                    if (!string.IsNullOrEmpty(dataAfterPM))
                    {
                        EchoStreamData echoStreamData = DecodeHexData(processedData);

                        if (echoStreamDataInfos.Count == 0 || CheckLastActivationIsDifferThanCurrent(echoStreamDataInfos, echoStreamData))
                        {
                            echoStreamDataInfos.Add(echoStreamData);
                            //Console.ForegroundColor = ConsoleColor.Green;
                            //Console.WriteLine($"{echoStreamDataInfos.Count}:{activationTriggeredFrom}");
                            //Console.WriteLine("---------------------------");
                            //Console.WriteLine($"Repeater Id: { echoStreamData.FirstHopUniqueId}");
                            //Console.WriteLine($"Repeater Name: {GetRepeaterName(echoStreamData.FirstHopUniqueId)}");
                            //Console.WriteLine($"Activation Bytes: {processedData}");                           
                            //Console.WriteLine($"Signal Level: {echoStreamData.SignalLevel}");
                            //Console.WriteLine($"Signal Margin: {echoStreamData.SignalMargin}\n");

                            if (echoStreamDataInfos.Count == 52)
                            {
                                break;
                            }
                        }
                        else
                        {
                            totalActivationCount += echoStreamDataInfos.Count();
                            ProcessActivationReport(echoStreamDataInfos, activationTriggeredFrom);
                            repeaterCaptureCount = new Dictionary<int, int>();
                            echoStreamDataInfos = new List<EchoStreamData>
                            {
                                echoStreamData
                            };
                        }
                    }
                }
            }
            Console.WriteLine(totalActivationCount);

        }

        private void ProcessActivationReport(List<EchoStreamData> echoStreamDataInfos, string activationTriggeredFrom)
        {

            //ActivationReport activationReport = new();

            var firstHopDeviceUniqueCount = echoStreamDataInfos.DistinctBy(x => x.FirstHopUniqueId).ToList().Select(x => x.FirstHopUniqueId);

            //activationReport.ActivationCount = echoStreamDataInfos.Count();
            //activationReport.RepeaterCount = firstHopDeviceUniqueCount.Count();
            //activationReport.Repeaters = new List<int>();
            //activationReport.Repeaters.AddRange(firstHopDeviceUniqueCount);

            //keyValuePairs[activationTriggeredFrom] = activationReport;

            foreach (EchoStreamData echoStream in echoStreamDataInfos)
            {
                //if(echoStream.SignalLevel > 30)
                //{
                    if (repeaterCaptureCount.ContainsKey(echoStream.FirstHopUniqueId))
                    {
                        repeaterCaptureCount[echoStream.FirstHopUniqueId] += 1;
                    }
                    else
                    {
                        repeaterCaptureCount[echoStream.FirstHopUniqueId] = 1;
                    }
                //}
         

                //_ = keyValuePairs.ContainsKey(i) ? keyValuePairs[i] += 1 : keyValuePairs[i] = 1;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"{activationTriggeredFrom}");
            Console.WriteLine("---------------------------");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Activation Type: {echoStreamDataInfos[0].ActivationType}\n");
            Console.WriteLine($"Activation Count: {echoStreamDataInfos.Count()}\n");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Captured Repeater Count: {firstHopDeviceUniqueCount.Count()}\n");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Repeater Details:");
            Console.WriteLine("---------------------------");
            Console.ForegroundColor = ConsoleColor.White;
            foreach (var entry in repeaterCaptureCount)
            {
                Console.WriteLine($"{GetRepeaterName(entry.Key)} - {entry.Key}: {entry.Value}");
            }
            Console.WriteLine("\n");
        }

        private bool CheckLastActivationIsDifferThanCurrent(List<EchoStreamData> echoStreamDataInfos, EchoStreamData echoStreamData)
        {
            if (echoStreamDataInfos[echoStreamDataInfos.Count - 1].ActivationType == echoStreamData.ActivationType)
            {
                return true;
            }
            return false;
        }

        private EchoStreamData DecodeHexData(string receivedHexData)
        {
            byte[] messageData = Enumerable.Range(0, receivedHexData.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(receivedHexData.Substring(x, 2), 16))
                             .ToArray();
            //byte[] messageData = Encoding.ASCII.GetBytes("7212B2B95650012F060300013E1A010001012A");
            EchoStreamData echoStreamData = new();

            echoStreamData.OriginatorUniqueId = GetUniqueId(messageData, 3);
            echoStreamData.FirstHopDevice = (EchoStreamFirstHopDevice)messageData[6];
            echoStreamData.FirstHopUniqueId = GetUniqueId(messageData, 7);
            echoStreamData.FirstHopRepeaterName = GetRepeaterName(echoStreamData.FirstHopUniqueId);
            echoStreamData.TraceCount = messageData[10];
            echoStreamData.HopCount = messageData[11];
            //It is a binary ("Short") message
            echoStreamData.ApplicationStatusFlags = (EchoStreamApplicationStatusFlags)messageData[14];
            echoStreamData.PrimaryStatusFlags = (EchoStreamPrimaryStatusFlags)messageData[15];
            echoStreamData.SignalLevel = messageData[16];
            echoStreamData.SignalMargin = messageData[17];
            echoStreamData.ActivationType = GetActivationType(echoStreamData.ApplicationStatusFlags, echoStreamData.PrimaryStatusFlags);

            //Console.WriteLine($"Name: {name}");
            //Console.WriteLine($"Activation Type: {GetActivationType(echoStreamData.ApplicationStatusFlags, echoStreamData.PrimaryStatusFlags)}");
            //Console.WriteLine($"First Hop Device: {echoStreamData.FirstHopDevice}");
            //Console.WriteLine($"First Hop Repeater: {echoStreamData.FirstHopRepeaterName}");
            //Console.WriteLine($"Serial Receiver Number: {echoStreamData.FirstHopUniqueId}");
            //Console.WriteLine($"Hop Count: {echoStreamData.HopCount}");
            ////GetActivationType(bytes);

            return echoStreamData;
        }

        private static string GetRepeaterName(int serialNumber)
        {
            return serialNumber switch
            {
                3081193 => "Repeater 1",
                2974235 => "Repeater 2",
                3081799 => "Repeater 3",
                3081345 => "Repeater 4",
                3081731 => "Repeater 5",
                3079702 => "Repeater 6",
                3081554 => "Repeater 7",
                3081530 => "Repeater 8",
                3081347 => "Repeater 9",
                3081034 => "Repeater 10",
                3081517 => "Repeater 11",
                3081556 => "Repeater 12",
                3081553 => "Repeater 13",
                _ => "RF Gateway"
            };
        }

        private static string GetActivationType(EchoStreamApplicationStatusFlags ApplicationStatusFlags, EchoStreamPrimaryStatusFlags PrimaryStatusFlags)
        {
            if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.PrimaryAlarm && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Unset)
            {
                return "First Activation";
            }
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Unset)
            {
                return "Clear with First Activation";
            }//Segregating bytes with EN1223S so it has OO OO with first activation itself, so consider reset is a first activation
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.NoChange)
            {
                return "CheckIn";
            }
            else if (ApplicationStatusFlags == EchoStreamApplicationStatusFlags.Unset && PrimaryStatusFlags == EchoStreamPrimaryStatusFlags.Reset)
            {
                return "Reset As Clear";
            }

            return "Unknown";
            //return (EchoStreamFirstHopDevice)messageData[6];            
        }


        private static int GetUniqueId(byte[] messageData, int startIndex)
        {

            //Create an array to copy in the uid data from the message data array
            byte[] uidData = new byte[4];

            //The start position of the destination array is 1 because we're copying 3 bytes into a 4 byte integer
            Array.Copy(messageData, startIndex, uidData, 1, 3);

            //Determine if this is a little endian machine and reverse the uid data array if so
            if (BitConverter.IsLittleEndian)
            {
                //reverse the order of the uid data array
                uidData = uidData.Reverse().ToArray();
            }

            //Get the unique id
            int uniqueId = BitConverter.ToInt32(uidData, 0);

            //return the result
            return uniqueId;
        }


    }
}


public class ActivationReport
{
    public int ActivationCount { get; set; }
    public int ClearCount { get; set; }
    public int RepeaterCount { get; set; }
    public int HopCount { get; set; }
    public List<int> Repeaters { get; set; }

}

public class EchoStreamData
{
    public int OriginatorUniqueId { get; set; }
    public string FirstHopRepeaterName { get; set; }
    public string ActivationType { get; set; }
    public EchoStreamFirstHopDevice FirstHopDevice { get; set; }
    public int FirstHopUniqueId { get; set; }
    public byte TraceCount { get; set; }
    public byte HopCount { get; set; }
    public EchoStreamApplicationStatusFlags ApplicationStatusFlags { get; set; } //This is also known as STAT1
    public EchoStreamPrimaryStatusFlags PrimaryStatusFlags { get; set; } //This is also known as STAT0
    public AverageRepeaterDataList AverageRepeaterData { get; set; } = new AverageRepeaterDataList();
    public Guid GlobalTrackingGuid { get; set; }
    public DateTime TimeCreatedUtc { get; set; }
    public byte ProductTypeIdentifier { get; set; }
    public byte SignalLevel { get; set; }
    public byte SignalMargin { get; set; }

}