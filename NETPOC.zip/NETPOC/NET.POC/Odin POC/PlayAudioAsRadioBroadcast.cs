﻿using NET.POC.Odin.Compute.Common.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Odin_POC
{
    public class PlayAudioAsRadioBroadcast
    {
        public static void Play()
        {
            // Prompt user to enter text
            Console.WriteLine("Enter the text you want to play:");
            string text = Console.ReadLine();

            //Get an output from the audio input
            using (MemoryStream audioMemoryStream = GetOutput(text))
            {
                //Create a sound player and send the sound player to the radio interface to play the message
                using (SoundPlayer player = new SoundPlayer(audioMemoryStream))
                {
                    //Play the file
                    player.PlaySync();
                }
            }

            Console.WriteLine("Press any key to exit...");
        }

        // Function to convert text to audio stream
        static MemoryStream TextToAudio(string text)
        {
            MemoryStream audioStream = new MemoryStream();
            // Here you need to implement the logic to convert text to audio
            // For example, you can use text-to-speech APIs or libraries like Microsoft Azure Cognitive Services Text-to-Speech
            // or any other text-to-speech library to generate audio from text and write it to the memory stream
            // Below is just a placeholder to demonstrate the concept
            // This example simply writes the text to the memory stream as bytes
            using (StreamWriter writer = new StreamWriter(audioStream))
            {
                writer.Write(text);
            }
            return audioStream;
        }


        static MemoryStream GetOutput(string text)
        {
            List<IAudioStreamGenerator> audioStreamGenerators = new List<IAudioStreamGenerator>();
            audioStreamGenerators.Add(GetTextToSpeechAudioStreamGenerator(text));
            //Create a list of memory streams and add the two audio inputs
            List<MemoryStream> audioStreams = new List<MemoryStream>();
            //Create the output stream
            MemoryStream outputStream = new MemoryStream();


            //Iterate all of the stream and concatenate them as the output stream
            foreach (IAudioStreamGenerator generator in audioStreamGenerators)
            {
                //Get a stream from the generator
                MemoryStream generatorStream = generator.GenerateAudioStream();

                //Check to make sure the generator stream is not null
                if (generatorStream != null)
                {
                    audioStreams.Add(generatorStream);
                }
            }

            //Check to make sure that we have at least one 
            if (audioStreams.Count > 0)
            {
                //Make sure there is more than one audio stream before we use the concatentation 
                if (audioStreams.Count > 1)
                {
                    //More than one audio stream, use the concatenator
                    //Get an audio file helper
                    AudioFileHelper audioFileHelper = new AudioFileHelper();

                    //Concatenate the streams
                    outputStream = audioFileHelper.ConcatenateAudioStreams(audioStreams);
                }
                else
                {
                    //There is only one audio stream, so just make it the outputs stream
                    outputStream = audioStreams.First();
                }

                //Reset the stream position
                outputStream.Position = 0;
            }

            //Return the output stream
            return outputStream;

        }


        public static IAudioStreamGenerator GetTextToSpeechAudioStreamGenerator(string textToSpeak, int millisecondsToTrimFromStart = 100, int millisecondsToTrimFromEnd = 760)
        {
            TextToSpeechAudioStreamGenerator _textToSpeechAudioStreamGenerator = new TextToSpeechAudioStreamGenerator();

            _textToSpeechAudioStreamGenerator.TextToSpeak = textToSpeak;
            _textToSpeechAudioStreamGenerator.MillisecondsToTrimFromStart = millisecondsToTrimFromStart;
            _textToSpeechAudioStreamGenerator.MillisecondsToTrimFromEnd = millisecondsToTrimFromEnd;
            return _textToSpeechAudioStreamGenerator;
        }

    }
}
