﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Class
{
    public class PartialClass
    {
        public partial class PartialTestClass
        {
            partial void DoSomething();

            public PartialTestClass() { DoSomething(); }
        }

        public partial class PartialTestClass
        {
            PartialTestClass(int a)
            {

            }
            partial void DoSomething() { /* code here */ }
        }
    }
}
