﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.DifferenceBetweenStructAndClass
{
    public class StructAndClass
    {
        #region Diff between struct and class

        public struct Employ
        {
            public string name;
            public int id;
        }

        public class Employ1
        {
            public string name;
            public int id;
        }

        public static void ChangeClassValue(Employ1 employ1)
        {
            employ1.id = 100;
        }


        public static void ChangeStructValue(Employ employ)
        {
            employ.id = 200;
            Console.WriteLine("Inside method");
            Console.WriteLine(employ.id);
            //return employ; 
        }
        #endregion

    }
}
