﻿using RJCP.IO.Ports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC
{
    public static class EN6050NetworkCoordinator
    {
        //Private field for the serial port used to connect to the transmitter
        static SerialPortStream _transmitterSerialPort = null;
        //This is buffer that is used to store data from the COM port.  
        private static byte[] _dataReceivedBuffer = new byte[8192];

        public static void EN6040()
        {


            string hexString = "1F040000";
            int checksum = 0;

            for (int i = 0; i < hexString.Length; i += 2)
            {
                string byteHex = hexString.Substring(i, 2);
                byte value = Convert.ToByte(byteHex, 16);
                checksum += value;
            }

            byte checksumByte = (byte)(checksum & 0xFF); // Get the lower eight bits

            Console.WriteLine($"Checksum: {checksumByte:X2}");


            string hexData = "340382B9"; //Activation
            //string hexData = "200700011737EA";

            byte[] byteData = StringToByteArray(hexData);

            // byte[] byteData = { 0x34, 0x04, 0x02,0x02, 0x3A };

            byte checkSum = CalculateChecksum(byteData);

            // Resize the byte array to accommodate the new byte
            //Array.Resize(ref byteData, byteData.Length + 1);

            // Assign the new byte to the last index of the array
            //byteData[byteData.Length - 1] = checkSum;

            // Type your username and press enter
            Console.WriteLine("Enter Port:");

            // Create a string variable and get user input from the keyboard and store it in the variable
            string port = Console.ReadLine();

            Connect(port);

            Transmit(byteData);

            Console.WriteLine($"Done!! {hexData}");

            Console.Read();

        }




        private static void Transmit(byte[] byteToSend)
        {
            _transmitterSerialPort.Write(byteToSend, 0, byteToSend.Length);
        }

        public static byte[] StringToByteArray(string hexString)
        {

            byte[] byteArray = new byte[hexString.Length / 2];

            for (int i = 0; i < byteArray.Length; i++)
            {
                byteArray[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            }
            return byteArray;

            //return Enumerable.Range(0, hex.Length)
            //                 .Where(x => x % 2 == 0)
            //                 .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
            //                 .ToArray();
        }




        public static void Connect(string comPort)
        {
            try
            {
                _transmitterSerialPort = new SerialPortStream(comPort, 9600, 8, Parity.None, StopBits.Two);
                _transmitterSerialPort.WriteTimeout = 5000;
                _transmitterSerialPort.DataReceived += listeningPort_DataReceived;
                _transmitterSerialPort.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }

        public static void listeningPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            var byteData = _transmitterSerialPort.Read(_dataReceivedBuffer, 0, _transmitterSerialPort.BytesToRead);
            string hexData = BitConverter.ToString(_dataReceivedBuffer).Replace("-", "");
            Console.WriteLine($"hexData: {hexData}");
        }


        /// <summary>
        /// Calculates the checksum.
        /// </summary>
        public static byte CalculateChecksum(byte[] predefinedBytes)
        {
            return (byte)predefinedBytes.Take(predefinedBytes.Length - 1).Sum(x => x);
        }


        /// <summary>
        /// Transmits the data.
        /// </summary>
        /// <param name="messageToWrite">The message to write.</param>
        public static void TransmitPayloadMessage(byte[] messageToWrite)
        {
            _transmitterSerialPort.Write(messageToWrite, 0, messageToWrite.Length);
        }

    }
}

