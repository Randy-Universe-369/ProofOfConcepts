﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace NET.POC.IQueryable_and_IEnumerable
{
    internal class IEnumerableAndIQueryable
    {

        List<int> ints = new List<int>()
            {
                1,2,3, 4,5, 6, 7, 8, 9, 10,
            };


        List<Student> studentList = new List<Student>()
            {
                new Student(){ID = 1, Name = "James", Gender = "Male"},
                new Student(){ID = 2, Name = "Sara", Gender = "Female"},
                new Student(){ID = 3, Name = "Steve", Gender = "Male"},
                new Student(){ID = 4, Name = "Pam", Gender = "Female"}
            };


        public IEnumerableAndIQueryable() { }

        //https://dotnettutorials.net/lesson/ienumerable-iqueryable-csharp/#:~:text=The%20IEnumerable%20interface%20is%20a,that%20iterates%20through%20a%20collection
        public void IEnumerableExample()
        {
            //In C#, all the collection classes (both generic and non-generic) implement the IEnumerable interface.
            //Whenever we want to work with in-memory objects, then we need to use the IEnumerabe interface 
            IEnumerable<int> querySyntax = from obj in ints
                                           where obj > 5
                                           select obj;

            List<int> ints2 = new List<int>();

            foreach (var item in querySyntax)
            {
                Console.WriteLine(item + " ");
            }


            //Linq Query to Fetch all students with Gender Male
            IEnumerable<Student> QuerySyntax = from std in studentList
                                               where std.Gender == "Male"
                                               select std;
            
            //Iterate through the collection
            foreach (var student in QuerySyntax)
            {
                Console.WriteLine($"ID : {student.ID}  Name : {student.Name}");
            }

        }


        public void IQueryableExample()
        {

            //To store the result in the IQuerable<Student> variable, we need to call the AsQueryable() method on the data source.
            //Linq Query to Fetch all students with Gender Male
            IQueryable<Student> MethodSyntax = studentList.AsQueryable()
                                 .Where(std => std.Gender == "Male");

            //Iterate through the collection
            foreach (var student in MethodSyntax)
            {
                Console.WriteLine($"ID : {student.ID}  Name : {student.Name}");
            }
        }


        /// <summary>
        /// Whenever we want to work with in-memory objects, then we need to use the IEnumerabe interface
        /// https://dotnettutorials.net/lesson/differences-between-ienumerable-and-iqueryable/
        /// </summary>
        public void IEnumerableIsInMemory()
        {
            //it will not use the TOP clause. So, here it will fetch all the Male Students’ data from SQL Server
            //to in-memory, and then it will filter the data in memory.

            //IEnumerable<Student> listStudents = DBContext.Students.Where(x => x.Gender == "Male");
            //listStudents = listStudents.Take(2);
        }

        /// <summary>
        /// Whenever we want to work with out-memory objects, then we need to use the IQueryable interface
        /// https://dotnettutorials.net/lesson/differences-between-ienumerable-and-iqueryable/
        /// </summary>
        public void IQueryableIsOutMemory()
        {
            //it includes the TOP (2) clause in the SQL Script and then fetches the data from the database.
            //That means now the filtering is happening on the database side. 

            //IQueryable<Student> listStudents = DBContext.Students
            //                     .AsQueryable()
            //                     .Where(x => x.Gender == "Male");
            //listStudents = listStudents.Take(2);
        }

    }
}


public class Student
{
    public int ID { get; set; }
    public string Name { get; set; }
    public string Gender { get; set; }
}


public static class Class1
{
    //private static void Class1()
    //{

    //}
}

abstract class AbstractClass
{

    public void test()
    {

    }
    public abstract void method();
}

class NormalClass : AbstractClass
{
    public override void method()
    {

    }
}