﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Constructor
{
    public class TypesOfConstructor
    {


        #region Private Constructor and mulitple constructor with diff param type
        //Ref https://stackoverflow.com/questions/2585836/why-do-we-need-a-private-constructor
        //Ref https://www.geeksforgeeks.org/private-constructors-in-c-sharp/
        public abstract class BaseClass
        {
            private BaseClass() { }

            public class SubClass1 : BaseClass
            {
                public SubClass1() : base() { }
            }

            public class SubClass2 : BaseClass
            {
                public SubClass2() : base() { }
            }
        }

        public class MyClass
        {
            private MyClass(object data1, string data2) { }

            public MyClass(object data1) : this(data1, null) { }

            public MyClass(string data2) : this(null, data2) { }

            public MyClass() : this(null, null) { }
        }
        #endregion


        #region Static Constructor
        class StaticConstructor
        {
            static StaticConstructor()
            {
                Console.WriteLine("Private Constructor");
            }
            static int value1 = 1;
            int value2 = 1;
            public static void Method1()
            {
                ++value1;
                Console.WriteLine($"Private Constructor Method 1 {value1}");
            }

            public void Method3()
            {
                ++value1;
                ++value2;
                Console.WriteLine($"Private Constructor Method 3 {value1}");
                Console.WriteLine($"Private Constructor Method 3 {value2}");
            }

            public static StaticConstructor Method2()
            {
                StaticConstructor privateConstructor = new StaticConstructor();

                return privateConstructor;
            }
        }

        #endregion


        #region Default Constructor and Interface
        interface ITest
        {
            void get();
        }

        interface ITrans
        {
            public void Get();
        }

        interface ITrans1 : ITrans
        {
            public void Set();
        }

        class Trans : ITrans1
        {
            public class T
            {
                public T()
                {

                }
            }

            private Trans()
            {

            }

            public void Set()
            {

            }

            public void Get()
            {

            }
        }

        abstract class Abs
        {
            public abstract void Get();
            public void Set()
            {

            }

        }

        class A : Abs
        {
            public override void Get()
            {
                throw new NotImplementedException();
            }
        }

        //Default Constructor
        class Test : ITest
        {
            int a;
            int b;

            // Default constructor
            public Test()
            {
                a = 10;
                b = 20;
            }

            public Test(Test test)
            {
                this.a = test.a;
                this.b = test.b;
            }

            // Method that receives 'this' 
            // keyword as parameter
            void display(Test obj)
            {
                Console.WriteLine("a = " + a + " b = " + b);
            }

            // Method that returns current
            // class instance
            public void get()
            {
                display(this);
            }

        }
        #endregion
    }
}
