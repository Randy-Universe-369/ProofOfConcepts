﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using NAudio.Wave;
using System.Speech.Synthesis;

namespace NET.POC.SendDataToMic
{
    public class SendDataToMicDevice
    {
        public void SendDataToMicroPhone()
        {
            Console.WriteLine("Enter text to be processed:");
            string text = Console.ReadLine();

            // Generate audio from text
            byte[] audioData = TextToSpeech.GenerateAudio(text);

            //// Play the generated audio
            //AudioPlayer.PlayAudio(audioData);


            // Send the generated audio to the virtual microphone
            MicrophoneSender.SendAudioToMicrophone(audioData);


            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }

    class TextToSpeech
    {
        public static byte[] GenerateAudio(string text)
        {
            using (var synthesizer = new SpeechSynthesizer())
            {
                // Set the voice (optional)
                synthesizer.SelectVoiceByHints(VoiceGender.Female, VoiceAge.Adult);

                // Convert text to audio
                var audioStream = new MemoryStream();
                synthesizer.SetOutputToWaveStream(audioStream);
                synthesizer.Speak(text);
                return audioStream.ToArray();
            }
        }
    }



    class MicrophoneSender
    {
        public static void SendAudioToMicrophone(byte[] audioData)
        {
            using (var waveProvider = new RawSourceWaveStream(new MemoryStream(audioData), new WaveFormat()))
            using (var waveIn = new WaveInEvent())
            {
                waveIn.WaveFormat = waveProvider.WaveFormat;
                waveIn.DataAvailable += (sender, e) =>
                {
                    byte[] buffer = new byte[e.BytesRecorded];
                    Array.Copy(e.Buffer, buffer, e.BytesRecorded);
                    // Simulate sending the audio to the microphone (you need a virtual audio cable for this)
                    // Here you would typically use a virtual audio cable or similar software
                };
                waveIn.StartRecording();

                // Simulate a recording session (adjust the time based on your needs)
                System.Threading.Thread.Sleep(TimeSpan.FromSeconds(5));

                waveIn.StopRecording();
            }
        }
    }

    class AudioPlayer
    {
        public static void PlayAudio(byte[] audioData)
        {
            using (var waveStream = new WaveFileReader(new MemoryStream(audioData)))
            using (var waveOut = new WaveOutEvent())
            {
                waveOut.Init(waveStream);
                waveOut.Play();
                while (waveOut.PlaybackState == PlaybackState.Playing)
                {
                    // Wait for audio playback to finish
                }
            }
        }
    }

}
