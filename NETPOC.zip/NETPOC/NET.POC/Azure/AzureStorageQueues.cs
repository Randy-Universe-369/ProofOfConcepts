﻿using Azure.Storage.Queues;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace NET.POC.Azure
{
    public class AzureStorageQueues
    {
        public async void AzureQueueStorage()
        {
            // Create a unique name for the queue
            // TODO: Replace the <storage-account-name> placeholder 
            string queueName = "test";
            string storageAccountName = "odindev001diag";

            // Instantiate a QueueClient to create and interact with the queue
            //QueueClient queueClient = new QueueClient(
            //    new Uri($"https://{storageAccountName}.queue.core.windows.net/{queueName}"),
            //    new DefaultAzureCredential());
            // Instantiate a QueueClient to create and interact with the queue
            string connectionString = "DefaultEndpointsProtocol=https;AccountName=odindev001diag;AccountKey=+dKz9P6uZK1E6o2yEVzAjL0+2rvgF5wS2AEVt7AQ3P8Ik408CrQXPM8y1GE31ufKgqgH7sk8yqb+R8E8o0XizQ==;EndpointSuffix=core.windows.net";
            QueueClient queueClient = new QueueClient(connectionString, queueName);
            // Create the queue
            var message = await queueClient.ReceiveMessageAsync();

            if (message.Value != null)
            {
                var receivedMessage = message.Value.MessageText;
            }
        }
    }
}
