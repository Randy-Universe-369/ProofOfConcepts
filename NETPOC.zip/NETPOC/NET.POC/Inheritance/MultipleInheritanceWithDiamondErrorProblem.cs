﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Inheritance
{
    public class MultipleInheritanceWithDiamondErrorProblem
    {
        #region inheritance with diamond error problem- multiple inheritance
        class D
        {
            public void Get()
            {

            }
        }

        public class BaseClassTest
        {
            public BaseClassTest()
            {

            }

            public int integer = 0;

            public void Get()
            {

            }

            public int GetClassB()
            {
                return 5;
            }
        }

        public class C : BaseClassTest
        {
            //int v = integer;
            void GetClassB()
            {
                GetClassB();
                Get();
                integer++;
            }

        }
        #endregion

    }
}
