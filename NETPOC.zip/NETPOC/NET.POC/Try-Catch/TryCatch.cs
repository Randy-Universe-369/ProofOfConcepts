﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Try_Catch
{
    public class TryCatch
    {
        #region Try-Catch
        private static void Caller()
        {
            try
            {
                called();
            }
            catch (Exception)
            {
                throw new Exception();

                throw;
            }
            finally
            {
                throw new Exception();
            }
        }

        private static void called()
        {
            try
            {
                throw new Exception();
            }
            catch (Exception)
            {
                //throw new Exception();

                throw;
            }
            finally
            {
                throw new Exception();
            }
        }
        #endregion

    }
}
