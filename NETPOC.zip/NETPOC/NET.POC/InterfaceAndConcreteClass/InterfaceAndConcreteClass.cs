﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NET.POC.Interface_and_Concrete_Class
{
    public class InterfaceAndConcreteClass
    {
        #region 1.interface inherits another interface    2. concrete class inherits another class and implements interface
        public interface IRepo1<TEntity> where TEntity : class
        {

            TEntity Get(int id);
            IEnumerable<TEntity> GetAll();
            void GetRepo1();
            void SetRepo1();
        }
        public class BLU
        {

        }
        public interface IRepo2 : IRepo1<BLU>
        {
            void GetRepo2();
        }

        public class Repo3
        {
            public int value = 1;
        }

        public class Concrete : Repo3//, IRepo2
        {
            public void GetRepo2()
            {
                value = 2;
            }

        }
        #endregion

    }
}
