﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NET.POC.RegexOperation
{
    public  class RegexClean
    {
        public static string RegexFunctionBlock()
        {
            string value = string.Empty;

            //string regexPattern = @"<th\s*class=""ContentPasted0""[^>]*>\s*Point\s*<\/th>\s*<td\s*class=""ContentPasted0""[^>]*>(.*?)<\/td>";
            //Get the output text
            string html = "<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\r\n<style type=\"text/css\" style=\"display:none;\"> P {margin-top:0;margin-bottom:0;} </style>\r\n</head>\r\n<body dir=\"ltr\">\r\n<div style=\"font-family: Aptos, Aptos_EmbeddedFont, Aptos_MSFontService, Calibri, Helvetica, sans-serif; font-size: 12pt; color: rgb(0, 0, 0);\" class=\"elementToProof\">\r\n<p class=\"ContentPasted0\" style=\"font-size: 14px; font-family: Verdana, Geneva, Arial, Helvetica, sans-serif; font-weight: bold; margin-top: 0px; margin-bottom: 0px; color: black; background-color: rgb(255, 255, 255);\">\r\nAdvisory Forwarding</p>\r\n<p class=\"ContentPasted0\" style=\"font-size: 12px; font-family: Verdana, Geneva, Arial, Helvetica, sans-serif; font-weight: bold; margin-top: 0px; margin-bottom: 0px; color: black; background-color: rgb(255, 255, 255);\">\r\nThis is an automatically generated email. Please do not respond. The following advisories have occurred:</p>\r\n<p class=\"ContentPasted0\" style=\"font-size: 12px; font-family: Verdana, Geneva, Arial, Helvetica, sans-serif; font-weight: bold; text-align: right; margin-top: 0px; margin-bottom: 0px; color: black; background-color: rgb(255, 255, 255);\">\r\nTime Perspective: Site Time</p>\r\n<br class=\"ContentPasted0\" style=\"font-family: &quot;Segoe UI&quot;, &quot;Segoe UI Web (West European)&quot;, &quot;Segoe UI&quot;, -apple-system, BlinkMacSystemFont, Roboto, &quot;Helvetica Neue&quot;, sans-serif; font-size: 15px; color: rgb(66, 66, 66); background-color: rgb(255, 255, 255);\">\r\n<br class=\"ContentPasted0\" style=\"font-family: &quot;Segoe UI&quot;, &quot;Segoe UI Web (West European)&quot;, &quot;Segoe UI&quot;, -apple-system, BlinkMacSystemFont, Roboto, &quot;Helvetica Neue&quot;, sans-serif; font-size: 15px; color: rgb(66, 66, 66); background-color: rgb(255, 255, 255);\">\r\n<div class=\"R1UVb\" style=\"font-size: 15px; font-family: &quot;Segoe UI&quot;, &quot;Segoe UI Web (West European)&quot;, &quot;Segoe UI&quot;, -apple-system, BlinkMacSystemFont, Roboto, &quot;Helvetica Neue&quot;, sans-serif; margin: 0px; overflow: hidden; color: rgb(66, 66, 66); background-color: rgb(255, 255, 255);\">\r\n<table align=\"center\" width=\"99%\" id=\"tableSelected1\" style=\"transform:scale(1, 1);transform-origin:left top\">\r\n<tbody>\r\n<tr style=\"background-color: rgb(157, 159, 254);\">\r\n<th class=\"ContentPasted0\">Occurrence Date</th>\r\n<th class=\"ContentPasted0\">Type</th>\r\n<th class=\"ContentPasted0\">Directory</th>\r\n<th class=\"ContentPasted0\">Site</th>\r\n<th class=\"ContentPasted0\">Control System</th>\r\n<th class=\"ContentPasted0\">Unit</th>\r\n<th class=\"ContentPasted0\">Application Type</th>\r\n<th class=\"ContentPasted0\">Application Instance</th>\r\n<th class=\"ContentPasted0\">Point</th>\r\n<th class=\"ContentPasted0\">Priority</th>\r\n<th class=\"ContentPasted0\">Advisory Message</th>\r\n<th class=\"ContentPasted0\">Source Type</th>\r\n<th class=\"ContentPasted0\">Advisory Limit</th>\r\n<th class=\"ContentPasted0\">Property Value</th>\r\n<th class=\"ContentPasted0\">Received Date</th>\r\n</tr>\r\n<tr>\r\n<td class=\"ContentPasted0\">10/11/23 7:19 AM PDT</td>\r\n<td class=\"ContentPasted0\">Alarm (rtn)</td>\r\n<td class=\"ContentPasted0\">WinCo Foods</td>\r\n<td class=\"ContentPasted0\">053 Folsom</td>\r\n<td class=\"ContentPasted0\">53 Folsom</td>\r\n<td class=\"ContentPasted0\">RX-300 1: WINCO#53</td>\r\n<td class=\"ContentPasted0\">Sensor Control DV</td>\r\n<td class=\"ContentPasted0\">GRFZ DOOR</td>\r\n<td class=\"ContentPasted0\">COMMAND OUT</td>\r\n<td class=\"ContentPasted0\">20</td>\r\n<td class=\"ContentPasted0\">Digital Sensor Alarm</td>\r\n<td class=\"ContentPasted0\">Device</td>\r\n<td class=\"ContentPasted0\">OFF</td>\r\n<td class=\"ContentPasted0\">OFF</td>\r\n<td class=\"ContentPasted0\">10/11/23 7:20 AM PDT</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n<br class=\"Apple-interchange-newline ContentPasted0\" style=\"background-color: rgb(255, 255, 255);\">\r\n<br>\r\n</div>\r\n</body>\r\n</html>\r\n\r\n";
            // Find the index of the "th" with the desired text (e.g., "Point")
            html = html.Replace(" ", String.Empty);
            int targetThIndex = FindThIndex(html, @"<th[^>]*>(.*?Occurrence Date.*?)</th>");
            string regexPattern = @"<(th|td)[^>]*>\s*(?<content>(?:(?!</\1>).)*)\s*<\/\1>";
            MatchCollection matches = Regex.Matches(html, regexPattern, RegexOptions.Singleline | RegexOptions.IgnoreCase);

            // Split "th" and "td" values separately
            List<string> thValues = new List<string>();
            List<string> tdValues = new List<string>();

            foreach (Match match in matches)
            {
                string elementContent = match.Groups["content"].Value.Trim();

                if (!string.IsNullOrEmpty(elementContent))
                {
                    if (match.Groups[1].Value.Equals("th", StringComparison.OrdinalIgnoreCase))
                    {
                        thValues.Add(elementContent);
                    }
                    else if (match.Groups[1].Value.Equals("td", StringComparison.OrdinalIgnoreCase))
                    {
                        tdValues.Add(elementContent);
                    }
                }
            }

            // Find the index of the target "th" containing "Point"
            targetThIndex = thValues.FindIndex(value => value.Equals("Point", StringComparison.OrdinalIgnoreCase));

            // Use targetThIndex to get the corresponding "td" value
            string correspondingTdContent = null;

            if (targetThIndex != -1 && targetThIndex < tdValues.Count)
            {
                correspondingTdContent = tdValues[targetThIndex];
            }

            // Use correspondingTdContent as needed
            Console.WriteLine(correspondingTdContent);

            //Return the output stream
            return value;
        }


        static int FindThIndex(string html, string targetText)
        {
            var matches = Regex.Matches(html, @"<th[^>]*>(.*?)<\/th>");
            for (int i = 0; i < matches.Count; i++)
            {
                //if (matches[i].Groups[1].Value.Contains(targetText))
                //{
                //    return i;
                //}
                var match = matches[i];
                var content = match.Groups[1].Value;

                if (Regex.IsMatch(match.Groups[0].Value, targetText, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace))
                {
                    return i;
                }
            }
            return -1;
        }

        static string ConstructRegexPattern()
        {
            // Construct the regex pattern to capture "th" and "td" elements
            return @"<(th|td)[^>]*>(?<content>\s*(?:(?!</\1>).)*\s*)<\/\1>";
        }

        private (int, string) FindThIndex1(string html, string targetText)
        {
            var matches = Regex.Matches(html, @"<th[^>]*>(.*?)<\/th>");
            for (int i = 0; i < matches.Count; i++)
            {
                //if (matches[i].Groups[1].Value.Contains(targetText))
                //{
                //    return i;
                //}
                Match match = matches[i];
                string content = match.Groups[1].Value;

                if (Regex.IsMatch(content, targetText))
                {
                    return (i, content);
                }
            }
            return (-1, string.Empty);
        }

    }
}
