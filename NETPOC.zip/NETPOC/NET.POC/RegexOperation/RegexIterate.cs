﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NET.POC.RegexOperation
{
    class RegexIterate
    {
        public void GetRegexResponse()
        {
            string value = string.Empty;

            string text = "<tdclass=\"ContentPasted0\">10/11/237:19AMPDT</td>\r\n<tdclass=\"ContentPasted0\">Alarm(rtn)</td>\r\n<tdclass=\"ContentPasted0\">WinCoFoods</td>\r\n<tdclass=\"ContentPasted0\">053Folsom</td>\r\n<tdclass=\"ContentPasted0\">53Folsom</td>\r\n<tdclass=\"ContentPasted0\">RX-3001:WINCO#53</td>\r\n<tdclass=\"ContentPasted0\">SensorControlDV</td>\r\n<tdclass=\"ContentPasted0\">GRFZDOOR</td>\r\n<tdclass=\"ContentPasted0\">COMMANDOUT</td>\r\n<tdclass=\"ContentPasted0\">20</td>\r\n<tdclass=\"ContentPasted0\">DigitalSensorAlarm</td>\r\n";

            // string pattern = @"<td class=""ContentPasted0"">(.*?)<\/td>\s*<td class=""ContentPasted0"">(.*?)<\/td>\s*<td class=""ContentPasted0"">(.*?)<\/td>";
            //string pattern = @"(?:<tdclass=""ContentPasted0"">(.*?)<\/td>\s*){11}";
            //string pattern = "(?:<tdclass=\"ContentPasted0\">(.*?)<\\/td>\\s*){11}";
            string pattern = @"<tdclass[^>]*>(.*?)<\/td>[^<]*$";
            text = text.Replace(" ", String.Empty);

            //Get the output text


            //The code below is done specially to parse First Face email content which comes with \r\n\r\n before
            //and after content. And the same has to be provided as Regex the extract content which lies between 
            //:STARTOFVALUE......ENDOFVALUE
            //Need to discuss with Bernie for an alternate method of handling this.
            text = Regex.Replace(text, "\r\n\r\n", "ENDOFVALUE");
            text = Regex.Replace(text, ":ENDOFVALUE", ":STARTOFVALUE");



            Match match = Regex.Match(text, pattern);
            if (match.Success)
            {
                //Checking for email messages.
                if (match.Groups[1].Value.Contains(":ENDOFVALUE") || match.Groups[1].Value.Contains("STARTOFVALUE"))
                {
                    value = match.Groups[1].Value;
                    value = value.Replace("STARTOFVALUE", "").Replace("ENDOFVALUE", "");
                }
                else //Normal text
                {
                    value = match.Groups[0].Value;
                }

            }

            //Return the output stream
            //return value;
        }
    }




    //Group the array:
    //		Input = ["Apple", "Orange", "Apple", "Banana", "Banana", "Apple"]

    //        Output = {
    //Apple: 3,
    //			Orange: 1,
    //			Banana: 2
    //}


    public class Sample
    {
        public void GetCountOfElement()
        {
            List<string> inputs = new List<string>()
        {
             "Orange", "Apple", "Banana", "Banana", "Apple"
        };

            List<string> uniqueInput = new List<string>();

            int elementCount = 0;
            int count = inputs.Count;

            for (int i = 0; i < count; i++)
            {
                if (!uniqueInput.Contains(inputs[i]))
                {
                    for (int j = 0; j < count; i++)
                    {
                        if (inputs[i] == inputs[j])
                        {
                            elementCount++;
                        }
                    }
                }

                uniqueInput.Add(inputs[i]);
                Console.WriteLine(inputs[i] + ":" + elementCount);
            }
        }
    }
}


